// This file has been prepared for Doxygen automatic documentation generation.
/*! \file ********************************************************************
*
* Atmel Corporation
*
* - File              : sensor_three_phase_BLDC.c
* - Compiler          : IAR EWAAVR 2.28a/3.10c
* - Support mail      : avr@atmel.com
* - Supported devices : All devices with 3 PWM channels on Timer1 and external Pin
*                       Interrupts can be used.
*                       The example is written for AT90CAN128
* - AppNote           : AVR452 - Sensor based control of three phases
*                       brushless DC motor with AT90CAN128 or MEGA128
* - Description       : Example of how to use an AT90CAN128 to control
*                       a brushless DC motor using Hall sensor for rotor
*                       position feedback.
*
* $Revision: 1.1 $
* $Date: Wednesday, January 25, 2006 07:38:42 UTC $
*****************************************************************************
*
*  Motor interface
*
* Signal Name     AT90CAN128 pin
*
*
*     WL                PB7
*     VL                PB6
*     UL                PB5
*     WH                PB4
*     VH                PB3
*     UH                PB2
*
*   Hall C              PE7
*   Hall B              PE6
*   Hall A              PE5
*
*******************************************************************************
*  CAN configuration
*
*  100K with 8 MHz crystal
*
*  Can frames that can be send to this target
*
*
*  type          id      data             action
*  Data frame    0x120   don't care       Stop motor
*  Data frame    0x121   don't care       Start motor
*  Data frame    0x122   HH LL            Set motor speed (speed=OxHHLL)
*  Data frame    0x123   XX               Set motor direction (XX=O=CCW or XX=1=CW)
*  remote frame  0x124   -----            DLC=2 to get back measured speed value.
*
*******************************************************************************/

#include <ioavr.h>
#include "mcu.h"
#include "compiler.h"

#include <inavr.h>
#include "sensor_three_phase_BLDC.h"



/*! \brief CCW rotation patterns.
 *
 * Configuration of pin drive levels and timer COM bits in different
 * phases for ClockWise and CounterClockWise rotation.
 */

unsigned char drvPatternsCCW[] = {0,0x30,0x44,0x50,0x88,0x28,0x84,0x83,0X23,0X23,0X0B,0X83,0x0B};
unsigned char drvPatternsCW[] =  {0,0X84,0X28,0x88,0X50,0X44,0X30,0x0B,0x83,0X0B,0X23,0X23,0x83};

						

unsigned int speed=0x100,measured_speed;
unsigned char num_channel, num_data,direction=CLOCKWISE;

__regvar __no_init unsigned char *pDrvPattern @14;

__regvar __no_init union _fastTemp{
  unsigned int word;
  struct{
    unsigned char LByte;
    unsigned char HByte;  //Hbyte = Zero
  };
} fastTemp @12;



__regvar __no_init unsigned char hallMask @11; //!< Workaround for internal compiler error
__regvar __no_init unsigned char count @10; //!< Optimized variable incremented every pin change int.

//! Pin Change Interrupt Service Routine.
void Hall_ISR(void)
{
  unsigned char *pTemp;
  fastTemp.word = ((PIN_HALL & hallMask)>>5);  // Read Hall, Mask Pins, shift to use as pointer offset

  pTemp = pDrvPattern + fastTemp.word;

  PORT_MC = *(pTemp);    //Change drive levels on high side

  TCCR1A = *(pTemp + PATTERN_COM1_OFFSET);    // Reconfigure output compare operation for T1

}


#pragma vector=INT5_vect        //! Pin Change Interrupt Service Routine.
__interrupt void INT5_ISR(void)
{
  count++;    // variable used to measure speed
  Hall_ISR();
}

#pragma vector=INT6_vect        //! Pin Change Interrupt Service Routine.
__interrupt void INT6_ISR(void)
{   Hall_ISR(); }


#pragma vector=INT7_vect        //! Pin Change Interrupt Service Routine.
__interrupt void INT7_ISR(void)
{  Hall_ISR(); }


#pragma vector=TIMER0_OVF_vect
__interrupt void   TIMER0_0VF_ISR(void)
{
  // calculation is done for Crystal at 8Mhz
  // count = nb loop per 32,768 ms (at 8Mhz)
  // measured_speed = Nb loop per minute
  // example: count = 29 --> nbloop = 29/2 (2 hall it by loop)
  // 60 sec /0.032768 = 1831
  //  8 poles = 4*2 poles
  // (29 * 1831.05) / 8 = 6637
  // result must be divide by 4 (for poles) and by 2 (2 hall IT by loop)
  // max speed measured (without charge) is 6637 loop/minute

  measured_speed = (count*1831)>>3;
  count=0;
}





//! Initialize pin interrupts for PORTB pin 5, 6 and 7
void Init_MC_pin_change_interrupt( void )
{
   EICRB = 0x54;  // pin int5 int6 int7 (PE5,PE6,PE7) configure on any level change
   EIMSK = 0xE0;  // enable int 5 6 7
}



//! Initialize timer0 for speed measurement
void Init_Speed_Timer0(void)
{
  TCCR0A  = (0<<COM0A1)|(0<<COM0A0)|
            (0<<FOC0A) |(0<<WGM00) |(0<<WGM01)|
            (0<<CS02)  |(0<<CS01)  |(1<<CS00);


  TIMSK0 =  (0<<OCIE0A)|(1<<TOIE0);
}


//! Initialize motor control timers.
void Init_MC_timer1_pwm( void )
{
  // FAST PWM 10 bits
  TCNT1=0x00;

  TCCR1A  = (1<<COM1A1)|(1<<COM1A0)|        // Clear OCRA on compare match
            (0<<COM1B1)|(0<<COM1B0)|        // Clear OCRB on compare match
            (0<<COM1C1)|(0<<COM1C0)|        // Clear OCRC on compare match
            (1<<WGM11)|(1<<WGM10);

  TCCR1B = (0<<ICNC1)|(0<<ICES1)|
           (0<<WGM13)|(1<<WGM12)|           // Fast PWM mode
           (0<<CS12)|(0<<CS11)|(1<<CS10); // Prescaler = CLK/1



  TIFR1 = TIFR1;    // Clear TC1 interrupt flags*/
}



//! Set motor speed, in PWM duty cycle.
void Set_Speed(unsigned int speed)
{


  TIFR1 = TIFR1;    // Clear TC1 interrupt flags
  while( !(TIFR1 & (1<<TOV1)));  // Wait for TOV to ensure that all registers are
                                //  updated in the same timer cycle
  __disable_interrupt();

      // Change the duty cycle
  OCR1AL = speed;
  OCR1AH = speed>>8;
  OCR1BL = speed;
  OCR1BH = speed>>8;
  OCR1CL = speed;
  OCR1CH = speed>>8;
  __enable_interrupt();
}




//! Set motor direction, CW og CCW.
void Set_Direction(unsigned char direction)
{
  if(direction == CLOCKWISE)
  {
    __disable_interrupt();         // Variable also used in interrupt and access must be protected
    pDrvPattern = drvPatternsCW;   // Set dir to CW, by pointing to CW pattern
    EIFR=EIFR;                     // Clear any pending Interrupt
    __enable_interrupt();
  }
  else
  {
    __disable_interrupt();         // Variable also used in interrupt and access must be protected
    pDrvPattern = drvPatternsCCW;  // Set dir to CCW, by pointing to CCW pattern
    EIFR=EIFR;                     // Clear any pending Interrupt
    __enable_interrupt();
  }
}

//! initialize port, timers, and initial direction
void motor_init()
{
  __disable_interrupt();
  MCUCR |= (1<<PUD);      // Disable all pull-ups
  hallMask = HALL_MASK;   // Initialize hallMask variable

  // Init_MC_timers();
  Init_MC_timer1_pwm();           // Timer1 used to generate PWM
  Init_MC_pin_change_interrupt(); // init pin for hall interrupt
  Init_Speed_Timer0();            // Timer used to calculate Speed
  //Set initial speed.
  Set_Speed(speed);
  //Set initial direction.
  Set_Direction(direction);
  DDR_HALL |= HALL_MASK;    //Lock HALL sensor by driving Hall lines
  PORT_HALL |= HALL_MASK;
  PORT_HALL &= ~HALL_MASK;  //Release HALL sensor lines and trigger PC interrupt
  DDR_HALL &= ~HALL_MASK;
  EIFR=EIFR;
  __enable_interrupt();
  DDR_MC |= 0xFF;
  DDRB|=0xFF;
}

void Run_motor(void)
{  DDR_MC  = 0xFF; }


void Stop_motor(void)
{  DDR_MC  = 0x00; }




void can_init(void)   // init CAN macro to received frames on channel O
    {                 // and to send frames on channel 1
  CANGCON |= MSK_CANGCON_GRES; /* reset CAN */
  /* reset all mailboxes */
  for (num_channel = 0; num_channel < 15; num_channel++)
  {
   CANPAGE  = num_channel << 4;
   CANCDMOB = CH_DISABLE;
   CANSTMOB  = 0;
   CANIDT1  = 0;
   CANIDT2  = 0;
   CANIDT3  = 0;
   CANIDT4  = 0;
   CANIDM1  = 0;
   CANIDM2  = 0;
   CANIDM3  = 0;
   CANIDM4  = 0;
   for (num_data = 0; num_data < 8; num_data++) CANMSG = 0;
   }
  /* setup bit timing at 100k with 8 MHz crystal*/
 CANBT1  = 0x08;
 CANBT2  = 0x0C;
 CANBT3  = 0x37;
 CANGCON |=  MSK_CANGCON_ENA;      /* start CAN */

 /* Channel 0 init */
 CANPAGE = (0 << 4);               /* CHNB=0x00; select channel 0 */
 CANSTMOB  = 0x00;                 /* reset channel status */
 CANCDMOB = CH_DISABLE;            /* reset control and dlc register */

 /* Channel 0: identifier = 11bits. CANIDT=0x123 */
 CANIDT1 = 0x24;
 CANIDT2 = 0x60;

 /* Channel 0: mask = 11bits. 0x7F0 */
 CANIDM1 = 0xFE;
 CANIDM2 &= ~0xE0;
 CANIDM4 = 0;

 /* Channel 0 configuration */
 CANIDT4 &=~0x04;                             /* clear bit rtr in CANIDT4. */
 CANCDMOB |= DLC_MAX;                         /* Reception 8 bytes.*/
 CANCDMOB |= CH_RxENA;                        /* Reception enabled without buffer.*/

  /* Channel 1 init */
 CANPAGE = (1 << 4);                          /* CHNB=0x01; select channel 1 */
 CANSTMOB  = 0x00;                            /* reset channel status */
 CANCDMOB = CH_DISABLE;                       /* reset control and dlc register */

 /* Channel 1: identifier = 11bits. CANIDT=0x123 */
 CANIDT1 = 0x24;
 CANIDT2 = 0x60;

 /* Channel 1: mask = 11bits. 0x7F0 */
 CANIDM1 = 0xFE;
 CANIDM2 &= ~0xE0;
 CANIDM4 = 0;
 /* interrupt configuration */
 CANIE2|=0x01;                                           /* IECH0=1 */
 CANGIE = ((1<<ENRX)|(1<<ENIT));              /* Can_Rx & IT enable */

}




#pragma vector=CANIT_vect      // CAN ISR
__interrupt void  CAN_ISR(void)
{

unsigned int id;                                      /* can_data index */

/* echo receive data on channel 0 reception */
 CANPAGE = (0 << 4);                          /* CHNB=0x00; select channel 0 */
 if((CANSTMOB & MSK_CANSTMOB_RxOk) == MSK_CANSTMOB_RxOk)
 {
 id = (((int)(CANIDT2))>>5) + (((int)(CANIDT1))<<3);       // V2.0 part A
 switch(id)
   {
     case(0x120): Stop_motor();    break; // Stop motor

     case(0x121):  Run_motor();     break; // Run motor

     case(0x122):  speed=(((int)(CANMSG))<<8);
                   speed = speed + (int)(CANMSG);

                   break; //  set speed

     case(0x123): direction=CANMSG;  break; // set direction motor

     case(0x124):  if ( (CANIDT4 & 0x04) == 0x04)
                    {
                         CANPAGE = (1 << 4);   /* select chanel 1 */
                         CANIDT2 = (char)(id << 5);
                         CANIDT1 = (char)(id >> 3);
                         CANMSG = (char)(measured_speed >> 8);
                         CANMSG = (char)(measured_speed);
                         CANSTMOB = 0x00;
                         CANCDMOB = 0x02;            /* transmit 2 bytes */
                         CANCDMOB |= CH_TxENA;     /* emission enabled */
                         //CANEN2 |= (1 << 1);       /* channel 1 enable */
                         CANPAGE = (0 << 4);    // select chanel 0
                      }
                     break;                  // send back measured speed
   }
 }

 CANPAGE = (0 << 4);
 CANSTMOB=0x00;                              /* reset channel 0 status */
 CANEN2 |= (1 << 0);                         /* channel 0 enable */
 CANCDMOB = DLC_MAX;                         /* receive 8 bytes */
 CANCDMOB |= CH_RxENA;                       /* reception enable */
 CANGIT = CANGIT;                            /* reset all flags */

}



void main( void )
{
  motor_init();
  can_init();

  for(;;)   // update speed and direction
  {
  Set_Speed(speed);
  Set_Direction(direction);
  }

}
