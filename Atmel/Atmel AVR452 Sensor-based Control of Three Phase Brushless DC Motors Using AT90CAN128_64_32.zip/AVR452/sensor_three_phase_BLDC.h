// This file has been prepared for Doxygen automatic documentation generation.
/*! \file ********************************************************************
*
* Atmel Corporation
*
* - File              : sensor_three_phase_BLDC.c
* - Compiler          : IAR EWAAVR 2.28a/3.10c
* - Support mail      : avr@atmel.com
* - Supported devices : All devices with 3 PWM channels on Timer1 and external Pin
*                       Interrupts can be used.
*                       The example is written for AT90CAN128
* - AppNote           : AVR452 - Sensor based control of three phases
*                       brushless DC motor with AT90CAN128 or MEGA128
* - Description       : Example of how to use an AT90CAN128 to control
*                       a brushless DC motor using Hall sensor for rotor
*                       position feedback.
*
* $Revision: 1.1 $
* $Date: Wednesday, January 25, 2006 07:38:42 UTC $
*****************************************************************************/

//! \name Output pins to drive stages.
//@{
#define WL  PB7
#define VL  PB6
#define UL  PB5
#define WH  PB4
#define VH  PB3
#define UH  PB2

#define MC_MASK   ((1<<UL)|(1<<VL)|(1<<WL)|(1<<UH)|(1<<VH)|(1<<WH))
//@}

//! \name Port control registers for drive stages.
//@{
#define PORT_MC PORTB
#define DDR_MC  DDRB
#define PIN_MC  PINB
//@}

//! \name Hall sensor input pins.
//@{
#define HALL1 PE5
#define HALL2 PE6
#define HALL3 PE7
#define HALL_MASK  ((1<<HALL1)|(1<<HALL2)|(1<<HALL3))
//@}


//! \name Port control registers for Hall sensor inputs.
//@{
#define PORT_HALL PORTE
#define DDR_HALL  DDRE
#define PIN_HALL  PINE
//@}


#define PATTERN_DRV_OFFSET  0 //!< Offset for drive pattern in table.
#define PATTERN_COM1_OFFSET 6 //!< Offset for Timer 0 Output Compare config pattern in table.


//! \name PWM output configuration (for both TC0 and TC2)
//@{
#define UL_ON   ((1<<COM1A1)|(0<<COM1A0))
#define UL_OFF  ((0<<COM1A1)|(0<<COM1A0))
#define VL_ON   ((1<<COM1B1)|(0<<COM1B0))
#define VL_OFF  ((0<<COM1B1)|(0<<COM1B0))
#define WL_ON   ((1<<COM1C1)|(0<<COM1C0))
#define WL_OFF  ((0<<COM1C1)|(0<<COM1C0))



// Direction control
#define CLOCKWISE         1 //!< Used by Set_Direction() for CW rotation.
#define COUNTERCLOCKWISE  0 //!< Used by Set_Direction() for CCW rotation.


/***********************************************/
//             CAN mask and define



#define MSK_CANGCON_ENA  	0x02
#define MSK_CANGCON_GRES 	0x01
#define DLC_MAX            8
#define CH_DISABLE         0x00
#define CH_RxENA           0x80
#define CH_TxENA           0x40
#define MSK_CANGIE_ENRX    0x20
#define MSK_CANGIE_ENTX    0x10
#define MSK_CANSTMOB_RxOk  0x20
/***********************************************/




