/****** THIS IS A MACHINE GENERATED FILE - DO NOT EDIT ******************** */
/****** Created: 2008-02-29 11:43 ******* Source: AT90PWM81.XML *********** */
/**************************************************************************
 *
 * - File Name          : "iopwm81.h"
 * - Title              : Register/Bit Definitions for the AT90PWM81
 * - Date               : 2008-02-29
 * - Version            : 2.21
 * - Support E-Mail     : avr@atmel.com
 * - Target MCU         : AT90PWM81
 *
 * - Compiler           : IAR Embedded Workbench - iccAVR and aAVR.
 *
 **************************************************************************
 */


#include "iomacro.h"

#if TID_GUARD(1)
#error This file should only be compiled with iccavr or aavr whith processor option -v1
#endif /* TID_GUARD(1) */

/* Include the SFR part if this file has not been included before,
* OR this file is included by the assembler (SFRs must be defined in
* each assembler module). */
#if !defined(__IOPWM81_H) || defined(__IAR_SYSTEMS_ASM__)

#pragma language=extended

/*==========================*/
/* Predefined SFR Addresses */
/*==========================*/


/* ***** SPECIFY DEVICE *************************************************** */
//#define  PART_NAME       AT90PWM81
#define    SIGNATURE_000   0x1e
#define    SIGNATURE_001   0x93
#define    SIGNATURE_002   0x88



/* ***** I/O REGISTER DEFINITIONS ***************************************** */
/* NOTE:
 * Definitions marked "MEMORY MAPPED"are extended I/O ports
 * and cannot be used with IN/OUT instructions
 */
SFR_B(MSMCR,	0x32)
SFR_B(DWDR,	0x31)
SFR_B(PASDLY2,	0x71)
SFR_B(BGCCR,	0x81)
SFR_B(BGCRR,	0x80)
SFR_B(PCNFE2,	0x70)
SFR_B(AC3ECON,	0x7c)
SFR_B(AC2ECON,	0x7b)
SFR_B(AC1ECON,	0x7a)
SFR_B(PICR2H,	0x6d)
SFR_B(PICR2L,	0x6c)
SFR_B(PFRC2B,	0x67)
SFR_B(PFRC2A,	0x66)
SFR_B(PCTL2,	0x16)
SFR_B(PCNF2,	0x15)

SFR_W(OCR2RB,	0x28)
//SFR_B(OCR2RBH,	0x29)
//SFR_B(OCR2RBL,	0x28)

//SFR_W(OCR2SB,	0x26)
SFR_B(OCR2SBH,	0x27)
SFR_B(OCR2SBL,	0x26)

SFR_W(OCR2RA,	0x2e)
//SFR_B(OCR2RAH,	0x2f)
//SFR_B(OCR2RAL,	0x2e)

//SFR_W(OCR2SA,	0x64)
SFR_B(OCR2SAH,	0x65)
SFR_B(OCR2SAL,	0x64)

SFR_B(POM2,	0x6f)
SFR_B(PSOC2,	0x6e)
SFR_B(PICR0H,	0x69)
SFR_B(PICR0L,	0x68)
SFR_B(PFRC0B,	0x63)
SFR_B(PFRC0A,	0x62)
SFR_B(PCTL0,	0x12)
SFR_B(PCNF0,	0x11)
SFR_B(OCR0RBH,	0x25)
SFR_B(OCR0RBL,	0x24)
SFR_B(OCR0SBH,	0x23)
SFR_B(OCR0SBL,	0x22)
SFR_B(OCR0RAH,	0x2b)
SFR_B(OCR0RAL,	0x2a)
SFR_B(OCR0SAH,	0x61)
SFR_B(OCR0SAL,	0x60)
SFR_B(PSOC0,	0x6a)
SFR_B(AC2CON,	0x7e)
SFR_B(AC1CON,	0x7d)
SFR_B(DACH,	0x39)
SFR_B(DACL,	0x38)
SFR_B(DACON,	0x76)
SFR_B(PIM2,	0x13)
SFR_B(PIFR2,	0x14)
SFR_B(PIM0,	0x0f)
SFR_B(PIFR0,	0x10)
SFR_W(ICR1,	0x8c)
SFR_W(TCNT1,	0x3a)
SFR_B(TCCR1B,	0x8a)
SFR_B(DIDR1,	0x78)
SFR_B(DIDR0,	0x77)
SFR_B(ADMUX,	0x08)
SFR_B(ADCSRB,	0x07)
SFR_B(ADCSRA,	0x06)
//SFR_B(ADCH,	0x2d)
//SFR_B(ADCL,	0x2c)
SFR_W(ADC,	0x2c)
SFR_B(AC3CON,	0x7f)
SFR_B(AMP0CSR,	0x79)
SFR_B(TIMSK1,	0x01)
SFR_B(EICRA,	0x89)
SFR_B(OSCCAL,	0x88)
SFR_B(PRR,	0x86)
SFR_B(CLKPR,	0x83)
SFR_B(WDTCSR,	0x82)
SFR_B(SREG,	0x3f)
SFR_W(SP,	0x3d)
SFR_B(SPMCSR,	0x37)
SFR_B(MCUCR,	0x35)
SFR_B(MCUSR,	0x34)
SFR_B(SMCR,	0x33)
SFR_B(ACSR,	0x00)
SFR_B(SPDR,	0x36)
SFR_B(SPSR,	0x18)
SFR_B(SPCR,	0x17)
SFR_B(PLLCSR,	0x87)
SFR_B(CLKSELR,	0x85)
SFR_B(CLKCSR,	0x84)
SFR_W(EEAR,	0x1e)
SFR_B(EEDR,	0x1d)
SFR_B(EECR,	0x1c)
SFR_B(GPIOR0,	0x19)
SFR_B(EIMSK,	0x21)
SFR_B(EIFR,	0x20)
SFR_B(GPIOR2,	0x1b)
SFR_B(GPIOR1,	0x1a)
SFR_B(TIFR1,	0x02)
SFR_B(PORTE,	0x0e)
SFR_B(DDRE,	0x0d)
SFR_B(PINE,	0x0c)
SFR_B(PORTD,	0x0b)
SFR_B(DDRD,	0x0a)
SFR_B(PIND,	0x09)
SFR_B(PORTB,	0x05)
SFR_B(DDRB,	0x04)
SFR_B(PINB,	0x03)



#ifndef __IOPWM81_H
#define __IOPWM81_H

//#ifdef __IAR_SYSTEMS_ASM__ 
#ifndef ENABLE_BIT_DEFINITIONS
#define  ENABLE_BIT_DEFINITIONS
#endif /* ENABLE_BIT_DEFINITIONS */
//#endif /* __IAR_SYSTEMS_ASM__ */

#ifdef ENABLE_BIT_DEFINITIONS
/* ***** BIT DEFINITIONS ************************************************** */

/* ***** PORTB ************************ */
/* PORTB - Port B Data Register */
#define    PORTB0          0       // Port B Data Register bit 0
#define    PORTB1          1       // Port B Data Register bit 1
#define    PORTB2          2       // Port B Data Register bit 2
#define    PORTB3          3       // Port B Data Register bit 3
#define    PORTB4          4       // Port B Data Register bit 4
#define    PORTB5          5       // Port B Data Register bit 5
#define    PORTB6          6       // Port B Data Register bit 6
#define    PORTB7          7       // Port B Data Register bit 7

/* DDRB - Port B Data Direction Register */
#define    DDB0            0       // Port B Data Direction Register bit 0
#define    DDB1            1       // Port B Data Direction Register bit 1
#define    DDB2            2       // Port B Data Direction Register bit 2
#define    DDB3            3       // Port B Data Direction Register bit 3
#define    DDB4            4       // Port B Data Direction Register bit 4
#define    DDB5            5       // Port B Data Direction Register bit 5
#define    DDB6            6       // Port B Data Direction Register bit 6
#define    DDB7            7       // Port B Data Direction Register bit 7

/* PINB - Port B Input Pins */
#define    PINB0           0       // Port B Input Pins bit 0
#define    PINB1           1       // Port B Input Pins bit 1
#define    PINB2           2       // Port B Input Pins bit 2
#define    PINB3           3       // Port B Input Pins bit 3
#define    PINB4           4       // Port B Input Pins bit 4
#define    PINB5           5       // Port B Input Pins bit 5
#define    PINB6           6       // Port B Input Pins bit 6
#define    PINB7           7       // Port B Input Pins bit 7


/* ***** PORTD ************************ */
/* PORTD - Port D Data Register */
#define    PORTD0          0       // Port D Data Register bit 0
#define    PORTD1          1       // Port D Data Register bit 1
#define    PORTD2          2       // Port D Data Register bit 2
#define    PORTD3          3       // Port D Data Register bit 3
#define    PORTD4          4       // Port D Data Register bit 4
#define    PORTD5          5       // Port D Data Register bit 5
#define    PORTD6          6       // Port D Data Register bit 6
#define    PORTD7          7       // Port D Data Register bit 7

/* DDRD - Port D Data Direction Register */
#define    DDD0            0       // Port D Data Direction Register bit 0
#define    DDD1            1       // Port D Data Direction Register bit 1
#define    DDD2            2       // Port D Data Direction Register bit 2
#define    DDD3            3       // Port D Data Direction Register bit 3
#define    DDD4            4       // Port D Data Direction Register bit 4
#define    DDD5            5       // Port D Data Direction Register bit 5
#define    DDD6            6       // Port D Data Direction Register bit 6
#define    DDD7            7       // Port D Data Direction Register bit 7

/* PIND - Port D Input Pins */
#define    PIND0           0       // Port D Input Pins bit 0
#define    PIND1           1       // Port D Input Pins bit 1
#define    PIND2           2       // Port D Input Pins bit 2
#define    PIND3           3       // Port D Input Pins bit 3
#define    PIND4           4       // Port D Input Pins bit 4
#define    PIND5           5       // Port D Input Pins bit 5
#define    PIND6           6       // Port D Input Pins bit 6
#define    PIND7           7       // Port D Input Pins bit 7


/* ***** DA_CONVERTER ***************** */
/* DACH - DAC Data Register High Byte */
#define    DACH0           0       // DAC Data Register High Byte Bit 0
#define    DACH1           1       // DAC Data Register High Byte Bit 1
#define    DACH2           2       // DAC Data Register High Byte Bit 2
#define    DACH3           3       // DAC Data Register High Byte Bit 3
#define    DACH4           4       // DAC Data Register High Byte Bit 4
#define    DACH5           5       // DAC Data Register High Byte Bit 5
#define    DACH6           6       // DAC Data Register High Byte Bit 6
#define    DACH7           7       // DAC Data Register High Byte Bit 7

/* DACL - DAC Data Register Low Byte */
#define    DACL0           0       // DAC Data Register Low Byte Bit 0
#define    DACL1           1       // DAC Data Register Low Byte Bit 1
#define    DACL2           2       // DAC Data Register Low Byte Bit 2
#define    DACL3           3       // DAC Data Register Low Byte Bit 3
#define    DACL4           4       // DAC Data Register Low Byte Bit 4
#define    DACL5           5       // DAC Data Register Low Byte Bit 5
#define    DACL6           6       // DAC Data Register Low Byte Bit 6
#define    DACL7           7       // DAC Data Register Low Byte Bit 7

/* DACON - DAC Control Register */
#define    DAEN            0       // DAC Enable Bit
#define    DAOE            1       // DAC Output Enable Bit
#define    DALA            2       // DAC Left Adjust
#define    DATS0           4       // DAC Trigger Selection Bit 0
#define    DATS1           5       // DAC Trigger Selection Bit 1
#define    DATS2           6       // DAC Trigger Selection Bit 2
#define    DAATE           7       // DAC Auto Trigger Enable Bit


/* ***** PORTE ************************ */
/* PORTE - Port E Data Register */
#define    PORTE0          0       // 
#define    PORTE1          1       // 
#define    PORTE2          2       // 

/* DDRE - Port E Data Direction Register */
#define    DDE0            0       // 
#define    DDE1            1       // 
#define    DDE2            2       // 

/* PINE - Port E Input Pins */
#define    PINE0           0       // 
#define    PINE1           1       // 
#define    PINE2           2       // 


/* ***** SPI ************************** */
/* SPDR - SPI Data Register */
#define    SPDR0           0       // SPI Data Register bit 0
#define    SPDR1           1       // SPI Data Register bit 1
#define    SPDR2           2       // SPI Data Register bit 2
#define    SPDR3           3       // SPI Data Register bit 3
#define    SPDR4           4       // SPI Data Register bit 4
#define    SPDR5           5       // SPI Data Register bit 5
#define    SPDR6           6       // SPI Data Register bit 6
#define    SPDR7           7       // SPI Data Register bit 7

/* SPSR - SPI Status Register */
#define    SPI2X           0       // Double SPI Speed Bit
#define    WCOL            6       // Write Collision Flag
#define    SPIF            7       // SPI Interrupt Flag

/* SPCR - SPI Control Register */
#define    SPR0            0       // SPI Clock Rate Select 0
#define    SPR1            1       // SPI Clock Rate Select 1
#define    CPHA            2       // Clock Phase
#define    CPOL            3       // Clock polarity
#define    MSTR            4       // Master/Slave Select
#define    DORD            5       // Data Order
#define    SPE             6       // SPI Enable
#define    SPIE            7       // SPI Interrupt Enable


/* ***** WATCHDOG ********************* */
/* WDTCSR - Watchdog Timer Control Register */
#define    WDP0            0       // Watch Dog Timer Prescaler bit 0
#define    WDP1            1       // Watch Dog Timer Prescaler bit 1
#define    WDP2            2       // Watch Dog Timer Prescaler bit 2
#define    WDE             3       // Watch Dog Enable
#define    WDCE            4       // Watchdog Change Enable
#define    WDP3            5       // Watchdog Timer Prescaler Bit 3
#define    WDIE            6       // Watchdog Timeout Interrupt Enable
#define    WDIF            7       // Watchdog Timeout Interrupt Flag


/* ***** EXTERNAL_INTERRUPT *********** */
/* EICRA - External Interrupt Control Register A */
#define    ISC00           0       // External Interrupt Sense Control Bit
#define    ISC01           1       // External Interrupt Sense Control Bit
#define    ISC10           2       // External Interrupt Sense Control Bit
#define    ISC11           3       // External Interrupt Sense Control Bit
#define    ISC20           4       // External Interrupt Sense Control Bit
#define    ISC21           5       // External Interrupt Sense Control Bit

/* EIMSK - External Interrupt Mask Register */
#define    INT0            0       // External Interrupt Request 0 Enable
#define    INT1            1       // External Interrupt Request 1 Enable
#define    INT2            2       // External Interrupt Request 2 Enable

/* EIFR - External Interrupt Flag Register */
#define    INTF0           0       // External Interrupt Flag 0
#define    INTF1           1       // External Interrupt Flag 1
#define    INTF2           2       // External Interrupt Flag 2


/* ***** AD_CONVERTER ***************** */
/* ADMUX - The ADC multiplexer Selection Register */
#define    MUX0            0       // Analog Channel and Gain Selection Bits
#define    MUX1            1       // Analog Channel and Gain Selection Bits
#define    MUX2            2       // Analog Channel and Gain Selection Bits
#define    MUX3            3       // Analog Channel and Gain Selection Bits
#define    ADLAR           5       // Left Adjust Result
#define    REFS0           6       // Reference Selection Bit 0
#define    REFS1           7       // Reference Selection Bit 1

/* ADCSRA - The ADC Control and Status register */
#define    ADPS0           0       // ADC  Prescaler Select Bits
#define    ADPS1           1       // ADC  Prescaler Select Bits
#define    ADPS2           2       // ADC  Prescaler Select Bits
#define    ADIE            3       // ADC Interrupt Enable
#define    ADIF            4       // ADC Interrupt Flag
#define    ADATE           5       // ADC Auto Trigger Enable
#define    ADSC            6       // ADC Start Conversion
#define    ADEN            7       // ADC Enable

/* ADCH - ADC Data Register High Byte */
#define    ADCH0           0       // ADC Data Register High Byte Bit 0
#define    ADCH1           1       // ADC Data Register High Byte Bit 1
#define    ADCH2           2       // ADC Data Register High Byte Bit 2
#define    ADCH3           3       // ADC Data Register High Byte Bit 3
#define    ADCH4           4       // ADC Data Register High Byte Bit 4
#define    ADCH5           5       // ADC Data Register High Byte Bit 5
#define    ADCH6           6       // ADC Data Register High Byte Bit 6
#define    ADCH7           7       // ADC Data Register High Byte Bit 7

/* ADCL - ADC Data Register Low Byte */
#define    ADCL0           0       // ADC Data Register Low Byte Bit 0
#define    ADCL1           1       // ADC Data Register Low Byte Bit 1
#define    ADCL2           2       // ADC Data Register Low Byte Bit 2
#define    ADCL3           3       // ADC Data Register Low Byte Bit 3
#define    ADCL4           4       // ADC Data Register Low Byte Bit 4
#define    ADCL5           5       // ADC Data Register Low Byte Bit 5
#define    ADCL6           6       // ADC Data Register Low Byte Bit 6
#define    ADCL7           7       // ADC Data Register Low Byte Bit 7

/* ADCSRB - ADC Control and Status Register B */
#define    ADTS0           0       // ADC Auto Trigger Source 0
#define    ADTS1           1       // ADC Auto Trigger Source 1
#define    ADTS2           2       // ADC Auto Trigger Source 2
#define    ADTS3           3       // ADC Auto Trigger Source 3
#define    ADSSEN          4       // ADC Single Shot Enable on PSC's Synchronisation Signals
#define    ADNCDIS         6       // ADC Noise Canceller Disable
#define    ADHSM           7       // ADC High Speed Mode

/* DIDR0 - Digital Input Disable Register 0 */
#define    ADC0D           0       // ADC0 Digital input Disable
#define    ADC1D           1       // ADC1 Digital input Disable
#define    ADC2D           2       // ADC2 Digital input Disable
#define    ADC3D           3       // ADC3 Digital input Disable
#define    ADC4D           4       // ADC4 Digital input Disable
#define    ADC5D           5       // ADC5 Digital input Disable
#define    ADC7D           6       // ADC7 Digital input Disable
#define    ADC8D           7       // 

/* DIDR1 - Digital Input Disable Register 0 */
#define    ADC9D           0       // 
#define    ADC10D          1       // 
#define    AMP0PD          2       // 
#define    ACMP1MD         3       // 

/* AMP0CSR -  */
#define    AMP0TS0         0       // 
#define    AMP0TS1         1       // 
#define    AMP0GS          3       // 
#define    AMP0G0          4       // 
#define    AMP0G1          5       // 
#define    AMP0IS          6       // 
#define    AMP0EN          7       // 


/* ***** ANALOG_COMPARATOR ************ */
/* AC3CON - Analog Comparator3 Control Register */
#define    AC3M0           0       // Analog Comparator 3 Multiplexer Register
#define    AC3M1           1       // Analog Comparator  3 Multiplexer Regsiter
#define    AC3M2           2       // Analog Comparator 3 Multiplexer Register
#define    AC3OEA          3       // Analog Comparator 3 Alternate Output Enable
#define    AC3IS0          4       // Analog Comparator 3  Interrupt Select Bit
#define    AC3IS1          5       // Analog Comparator 3  Interrupt Select Bit
#define    AC3IE           6       // Analog Comparator 3 Interrupt Enable Bit
#define    AC3EN           7       // Analog Comparator3 Enable Bit

/* AC1CON - Analog Comparator 1 Control Register */
#define    AC1M0           0       // Analog Comparator 1 Multiplexer Register
#define    AC1M1           1       // Analog Comparator 1 Multiplexer Regsiter
#define    AC1M2           2       // Analog Comparator 1 Multiplexer Register
#define    AC1IS0          4       // Analog Comparator 1 Interrupt Select Bit
#define    AC1IS1          5       // Analog Comparator 1  Interrupt Select Bit
#define    AC1IE           6       // Analog Comparator 1 Interrupt Enable Bit
#define    AC1EN           7       // Analog Comparator 1 Enable Bit

/* AC2CON - Analog Comparator 2 Control Register */
#define    AC2M0           0       // Analog Comparator 2 Multiplexer Register
#define    AC2M1           1       // Analog Comparator 2 Multiplexer Regsiter
#define    AC2M2           2       // Analog Comparator 2 Multiplexer Register
#define    AC2IS0          4       // Analog Comparator 2 Interrupt Select Bit
#define    AC2IS1          5       // Analog Comparator 2  Interrupt Select Bit
#define    AC2IE           6       // Analog Comparator 2 Interrupt Enable Bit
#define    AC2EN           7       // Analog Comparator 2 Enable Bit

/* ACSR - Analog Comparator Status Register */
#define    AC1O            1       // Analog Comparator 1 Output Bit
#define    AC2O            2       // Analog Comparator 2 Output Bit
#define    AC3O            3       // Analog Comparator 3 Output Bit
#define    AC1IF           5       // Analog Comparator 1  Interrupt Flag Bit
#define    AC2IF           6       // Analog Comparator 2 Interrupt Flag Bit
#define    AC3IF           7       // Analog Comparator 3 Interrupt Flag Bit

/* AC3ECON -  */
#define    AC3H0           0       // Analog Comparator Hysteresis Select
#define    AC3H1           1       // Analog Comparator Hysteresis Select
#define    AC3H2           2       // Analog Comparator Hysteresis Select
#define    AC3ICE          3       // Analog Comparator Interrupt Capture Enable
#define    AC3OE           4       // Analog Comparator Ouput Enable
#define    AC3OI           5       // Analog Comparator Ouput Invert

/* AC2ECON -  */
#define    AC2H0           0       // Analog Comparator Hysteresis Select
#define    AC2H1           1       // Analog Comparator Hysteresis Select
#define    AC2H2           2       // Analog Comparator Hysteresis Select
#define    AC2ICE          3       // Analog Comparator Interrupt Capture Enable
#define    AC2OE           4       // Analog Comparator Ouput Enable
#define    AC2OI           5       // Analog Comparator Ouput Invert

/* AC1ECON -  */
#define    AC1H0           0       // Analog Comparator Hysteresis Select
#define    AC1H1           1       // Analog Comparator Hysteresis Select
#define    AC1H2           2       // Analog Comparator Hysteresis Select
#define    AC1ICE          3       // Analog Comparator Interrupt Capture Enable
#define    AC1OE           4       // Analog Comparator Ouput Enable
#define    AC1OI           5       // Analog Comparator Ouput Invert


/* ***** CPU ************************** */
/* SREG - Status Register */
#define    SREG_C          0       // Carry Flag
#define    SREG_Z          1       // Zero Flag
#define    SREG_N          2       // Negative Flag
#define    SREG_V          3       // Two's Complement Overflow Flag
#define    SREG_S          4       // Sign Bit
#define    SREG_H          5       // Half Carry Flag
#define    SREG_T          6       // Bit Copy Storage
#define    SREG_I          7       // Global Interrupt Enable

/* MCUCR - MCU Control Register */
#define    IVCE            0       // Interrupt Vector Change Enable
#define    IVSEL           1       // Interrupt Vector Select
#define    CKRC81          2       // Frequency Selection of the Calibrated RC Oscillator
#define    RSTDIS          3       // Reset Pin Disable
#define    PUD             4       // Pull-up disable

/* MCUSR - MCU Status Register */
#define    PORF            0       // Power-on reset flag
#define    EXTRF           1       // External Reset Flag
#define    BORF            2       // Brown-out Reset Flag
#define    WDRF            3       // Watchdog Reset Flag

/* OSCCAL - Oscillator Calibration Value */
#define    CAL0            0       // Oscillator Calibration Value Bit0
#define    CAL1            1       // Oscillator Calibration Value Bit1
#define    CAL2            2       // Oscillator Calibration Value Bit2
#define    CAL3            3       // Oscillator Calibration Value Bit3
#define    CAL4            4       // Oscillator Calibration Value Bit4
#define    CAL5            5       // Oscillator Calibration Value Bit5
#define    CAL6            6       // Oscillator Calibration Value Bit6

/* CLKPR -  */
#define    CLKPS0          0       // 
#define    CLKPS1          1       // 
#define    CLKPS2          2       // 
#define    CLKPS3          3       // 
#define    CLKPCE          7       // 

/* SMCR - Sleep Mode Control Register */
#define    SE              0       // Sleep Enable
#define    SM0             1       // Sleep Mode Select bit 0
#define    SM1             2       // Sleep Mode Select bit 1
#define    SM2             3       // Sleep Mode Select bit 2

/* GPIOR2 - General Purpose IO Register 2 */
#define    GPIOR20         0       // General Purpose IO Register 2 bit 0
#define    GPIOR21         1       // General Purpose IO Register 2 bit 1
#define    GPIOR22         2       // General Purpose IO Register 2 bit 2
#define    GPIOR23         3       // General Purpose IO Register 2 bit 3
#define    GPIOR24         4       // General Purpose IO Register 2 bit 4
#define    GPIOR25         5       // General Purpose IO Register 2 bit 5
#define    GPIOR26         6       // General Purpose IO Register 2 bit 6
#define    GPIOR27         7       // General Purpose IO Register 2 bit 7

/* GPIOR1 - General Purpose IO Register 1 */
#define    GPIOR10         0       // General Purpose IO Register 1 bit 0
#define    GPIOR11         1       // General Purpose IO Register 1 bit 1
#define    GPIOR12         2       // General Purpose IO Register 1 bit 2
#define    GPIOR13         3       // General Purpose IO Register 1 bit 3
#define    GPIOR14         4       // General Purpose IO Register 1 bit 4
#define    GPIOR15         5       // General Purpose IO Register 1 bit 5
#define    GPIOR16         6       // General Purpose IO Register 1 bit 6
#define    GPIOR17         7       // General Purpose IO Register 1 bit 7

/* GPIOR0 - General Purpose IO Register 0 */
#define    GPIOR00         0       // General Purpose IO Register 0 bit 0
#define    GPIOR01         1       // General Purpose IO Register 0 bit 1
#define    GPIOR02         2       // General Purpose IO Register 0 bit 2
#define    GPIOR03         3       // General Purpose IO Register 0 bit 3
#define    GPIOR04         4       // General Purpose IO Register 0 bit 4
#define    GPIOR05         5       // General Purpose IO Register 0 bit 5
#define    GPIOR06         6       // General Purpose IO Register 0 bit 6
#define    GPIOR07         7       // General Purpose IO Register 0 bit 7

/* PLLCSR - PLL Control And Status Register */
#define    PLOCK           0       // PLL Lock Detector
#define    PLLE            1       // PLL Enable
#define    PLLF0           2       // 
#define    PLLF1           3       // 
#define    PLLF2           4       // 
#define    PLLF3           5       // 

/* PRR - Power Reduction Register */
#define    PRADC           0       // Power Reduction ADC
#define    PRUSART0        1       // Power Reduction USART
#define    PRSPI           2       // Power Reduction Serial Peripheral Interface
#define    PRTIM0          3       // Power Reduction Timer/Counter0
#define    PRTIM1          4       // Power Reduction Timer/Counter1
#define    PRPSC0          5       // Power Reduction PSC0
#define    PRPSC1          6       // Power Reduction PSC1
#define    PRPSC2          7       // Power Reduction PSC2

/* CLKCSR -  */
#define    CLKC0           0       // Clock Control
#define    CLKC1           1       // Clock Control
#define    CLKC2           2       // Clock Control
#define    CLKC3           3       // Clock Control
#define    CLKRDY          4       // Clock Ready Flag
#define    CLKCCE          7       // Clock Control Change Enable

/* CLKSELR -  */
#define    CKSEL0          0       // Clock Source Select
#define    CKSEL1          1       // Clock Source Select
#define    CKSEL2          2       // Clock Source Select
#define    CKSEL3          3       // Clock Source Select
#define    CSUT0           4       // Clock Start up Time
#define    CSUT1           5       // Clock Start up Time
#define    COUT            6       // Clock OUT

/* BGCCR - BandGap Current Calibration Register */
#define    BGCC0           0       // 
#define    BGCC1           1       // 
#define    BGCC2           2       // 
#define    BGCC3           3       // 

/* BGCRR - BandGap Resistor Calibration Register */
#define    BGCR0           0       // 
#define    BGCR1           1       // 
#define    BGCR2           2       // 
#define    BGCR3           3       // 


/* ***** EEPROM *********************** */
/* EEDR - EEPROM Data Register */
#define    EEDR0           0       // EEPROM Data Register bit 0
#define    EEDR1           1       // EEPROM Data Register bit 1
#define    EEDR2           2       // EEPROM Data Register bit 2
#define    EEDR3           3       // EEPROM Data Register bit 3
#define    EEDR4           4       // EEPROM Data Register bit 4
#define    EEDR5           5       // EEPROM Data Register bit 5
#define    EEDR6           6       // EEPROM Data Register bit 6
#define    EEDR7           7       // EEPROM Data Register bit 7

/* EECR - EEPROM Control Register */
#define    EERE            0       // EEPROM Read Enable
#define    EEWE            1       // EEPROM Write Enable
#define    EEMWE           2       // EEPROM Master Write Enable
#define    EERIE           3       // EEPROM Ready Interrupt Enable
#define    EEPM0           4       // EEPROM Programming Mode
#define    EEPM1           5       // EEPROM Programming Mode
#define    EEPAGE          6       // EEPROM Page Access
#define    NVMBSY          7       // None Volatile Busy Memory Busy


/* ***** PSC0 ************************* */
/* PICR0H - PSC 0 Input Capture Register High */
#define    PICR0_8         0       // 
#define    PICR0_9         1       // 
#define    PICR0_10        2       // 
#define    PICR0_11        3       // 
#define    PCST0           7       // PSC 0 Capture Software Trigger Bit

/* PICR0L - PSC 0 Input Capture Register Low */
#define    PICR0_0         0       // 
#define    PICR0_1         1       // 
#define    PICR0_2         2       // 
#define    PICR0_3         3       // 
#define    PICR0_4         4       // 
#define    PICR0_5         5       // 
#define    PICR0_6         6       // 
#define    PICR0_7         7       // 

/* PFRC0B - PSC 0 Input B Control */
#define    PRFM0B0         0       // PSC 0 Retrigger and Fault Mode for Part B
#define    PRFM0B1         1       // PSC 0 Retrigger and Fault Mode for Part B
#define    PRFM0B2         2       // PSC 0 Retrigger and Fault Mode for Part B
#define    PRFM0B3         3       // PSC 0 Retrigger and Fault Mode for Part B
#define    PFLTE0B         4       // PSC 0 Filter Enable on Input Part B
#define    PELEV0B         5       // PSC 0 Edge Level Selector on Input Part B
#define    PISEL0B         6       // PSC 0 Input Select for Part B
#define    PCAE0B          7       // PSC 0 Capture Enable Input Part B

/* PFRC0A - PSC 0 Input A Control */
#define    PRFM0A0         0       // PSC 0 Retrigger and Fault Mode for Part A
#define    PRFM0A1         1       // PSC 0 Retrigger and Fault Mode for Part A
#define    PRFM0A2         2       // PSC 0 Retrigger and Fault Mode for Part A
#define    PRFM0A3         3       // PSC 0 Retrigger and Fault Mode for Part A
#define    PFLTE0A         4       // PSC 0 Filter Enable on Input Part A
#define    PELEV0A         5       // PSC 0 Edge Level Selector on Input Part A
#define    PISEL0A         6       // PSC 0 Input Select for Part A
#define    PCAE0A          7       // PSC 0 Capture Enable Input Part A

/* PCTL0 - PSC 0 Control Register */
#define    PRUN0           0       // PSC 0 Run
#define    PCCYC0          1       // PSC0 Complete Cycle
#define    PBFM00          2       // PSC 0 Balance Flank Width Modulation
#define    PAOC0A          3       // PSC 0 Asynchronous Output Control A
#define    PAOC0B          4       // PSC 0 Asynchronous Output Control B
#define    PBFM01          5       // PSC 0 Balance Flank Width Modulation
#define    PPRE00          6       // PSC 0 Prescaler Select 0
#define    PPRE01          7       // PSC 0 Prescaler Select 1

/* PCNF0 - PSC 0 Configuration Register */
#define    PCLKSEL0        1       // PSC 0 Input Clock Select
#define    POP0            2       // PSC 0 Output Polarity
#define    PMODE00         3       // PSC 0 Mode
#define    PMODE01         4       // PSC 0 Mode
#define    PLOCK0          5       // PSC 0 Lock
#define    PALOCK0         6       // PSC 0 Autolock
#define    PFIFTY0         7       // PSC 0 Fifty

/* OCR0RBH - Output Compare RB Register High */
#define    OCR0RB_8        0       // 
#define    OCR0RB_9        1       // 
#define    OCR0RB_00       2       // 
#define    OCR0RB_01       3       // 
#define    OCR0RB_02       4       // 
#define    OCR0RB_03       5       // 
#define    OCR0RB_04       6       // 
#define    OCR0RB_05       7       // 

/* OCR0RBL - Output Compare RB Register Low */
#define    OCR0RB_0        0       // 
#define    OCR0RB_1        1       // 
#define    OCR0RB_2        2       // 
#define    OCR0RB_3        3       // 
#define    OCR0RB_4        4       // 
#define    OCR0RB_5        5       // 
#define    OCR0RB_6        6       // 
#define    OCR0RB_7        7       // 

/* OCR0SBH - Output Compare SB Register High */
#define    OCR0SB_8        0       // 
#define    OCR0SB_9        1       // 
#define    OCR0SB_00       2       // 
#define    OCR0SB_01       3       // 

/* OCR0SBL - Output Compare SB Register Low */
#define    OCR0SB_0        0       // 
#define    OCR0SB_1        1       // 
#define    OCR0SB_2        2       // 
#define    OCR0SB_3        3       // 
#define    OCR0SB_4        4       // 
#define    OCR0SB_5        5       // 
#define    OCR0SB_6        6       // 
#define    OCR0SB_7        7       // 

/* OCR0RAH - Output Compare RA Register High */
#define    OCR0RA_8        0       // 
#define    OCR0RA_9        1       // 
#define    OCR0RA_00       2       // 
#define    OCR0RA_01       3       // 

/* OCR0RAL - Output Compare RA Register Low */
#define    OCR0RA_0        0       // 
#define    OCR0RA_1        1       // 
#define    OCR0RA_2        2       // 
#define    OCR0RA_3        3       // 
#define    OCR0RA_4        4       // 
#define    OCR0RA_5        5       // 
#define    OCR0RA_6        6       // 
#define    OCR0RA_7        7       // 

/* OCR0SAH - Output Compare SA Register High */
#define    OCR0SA_8        0       // 
#define    OCR0SA_9        1       // 
#define    OCR0SA_00       2       // 
#define    OCR0SA_01       3       // 

/* OCR0SAL - Output Compare SA Register Low */
#define    OCR0SA_0        0       // 
#define    OCR0SA_1        1       // 
#define    OCR0SA_2        2       // 
#define    OCR0SA_3        3       // 
#define    OCR0SA_4        4       // 
#define    OCR0SA_5        5       // 
#define    OCR0SA_6        6       // 
#define    OCR0SA_7        7       // 

/* PSOC0 - PSC0 Synchro and Output Configuration */
#define    POEN0A          0       // PSCOUT00 Output Enable
#define    POEN0B          2       // PSCOUT01 Output Enable
#define    PSYNC01         5       // Synchronisation out for ADC selection
#define    PISEL0B1        6       // PSC Input Select
#define    PISEL0A1        7       // PSC Input Select

/* PIM0 - PSC0 Interrupt Mask Register */
#define    PEOPE0          0       // End of Cycle Interrupt Enable
#define    PEOEPE0         1       // End of Enhanced Cycle Enable
#define    PEVE0A          3       // External Event A Interrupt Enable
#define    PEVE0B          4       // External Event B Interrupt Enable

/* PIFR0 - PSC0 Interrupt Flag Register */
#define    PEOP0           0       // End of PSC0 Interrupt
#define    PRN00           1       // Ramp Number
#define    PRN01           2       // Ramp Number
#define    PEV0A           3       // External Event A Interrupt
#define    PEV0B           4       // External Event B Interrupt
#define    POAC0A          6       // PSC 0 Output A Activity
#define    POAC0B          7       // PSC 0 Output A Activity


/* ***** PSC2 ************************* */
/* PICR2H - PSC 2 Input Capture Register High */
#define    PICR2_8         0       // 
#define    PICR2_9         1       // 
#define    PICR2_10        2       // 
#define    PICR2_11        3       // 
#define    PCST2           7       // PSC 2 Capture Software Trigger Bit

/* PICR2L - PSC 2 Input Capture Register Low */
#define    PICR2_0         0       // 
#define    PICR2_1         1       // 
#define    PICR2_2         2       // 
#define    PICR2_3         3       // 
#define    PICR2_4         4       // 
#define    PICR2_5         5       // 
#define    PICR2_6         6       // 
#define    PICR2_7         7       // 

/* PFRC2B - PSC 2 Input B Control */
#define    PRFM2B0         0       // PSC 2 Retrigger and Fault Mode for Part B
#define    PRFM2B1         1       // PSC 2 Retrigger and Fault Mode for Part B
#define    PRFM2B2         2       // PSC 2 Retrigger and Fault Mode for Part B
#define    PRFM2B3         3       // PSC 2 Retrigger and Fault Mode for Part B
#define    PFLTE2B         4       // PSC 2 Filter Enable on Input Part B
#define    PELEV2B         5       // PSC 2 Edge Level Selector on Input Part B
#define    PISEL2B         6       // PSC 2 Input Select for Part B
#define    PCAE2B          7       // PSC 2 Capture Enable Input Part B

/* PFRC2A - PSC 2 Input B Control */
#define    PRFM2A0         0       // PSC 2 Retrigger and Fault Mode for Part A
#define    PRFM2A1         1       // PSC 2 Retrigger and Fault Mode for Part A
#define    PRFM2A2         2       // PSC 2 Retrigger and Fault Mode for Part A
#define    PRFM2A3         3       // PSC 2 Retrigger and Fault Mode for Part A
#define    PFLTE2A         4       // PSC 2 Filter Enable on Input Part A
#define    PELEV2A         5       // PSC 2 Edge Level Selector on Input Part A
#define    PISEL2A         6       // PSC 2 Input Select for Part A
#define    PCAE2A          7       // PSC 2 Capture Enable Input Part A

/* PCTL2 - PSC 2 Control Register */
#define    PRUN2           0       // PSC 2 Run
#define    PCCYC2          1       // PSC2 Complete Cycle
#define    PARUN2          2       // PSC2 Auto Run
#define    PAOC2A          3       // PSC 2 Asynchronous Output Control A
#define    PAOC2B          4       // PSC 2 Asynchronous Output Control B
#define    PBFM2           5       // Balance Flank Width Modulation
#define    PPRE20          6       // PSC 2 Prescaler Select 0
#define    PPRE21          7       // PSC 2 Prescaler Select 1

/* PCNF2 - PSC 2 Configuration Register */
#define    POME2           0       // PSC 2 Output Matrix Enable
#define    PCLKSEL2        1       // PSC 2 Input Clock Select
#define    POP2            2       // PSC 2 Output Polarity
#define    PMODE20         3       // PSC 2 Mode
#define    PMODE21         4       // PSC 2 Mode
#define    PLOCK2          5       // PSC 2 Lock
#define    PALOCK2         6       // PSC 2 Autolock
#define    PFIFTY2         7       // PSC 2 Fifty

/* OCR2RBH - Output Compare RB Register High */
#define    OCR2RB_8        0       // 
#define    OCR2RB_9        1       // 
#define    OCR2RB_10       2       // 
#define    OCR2RB_11       3       // 
#define    OCR2RB_12       4       // 
#define    OCR2RB_13       5       // 
#define    OCR2RB_14       6       // 
#define    OCR2RB_15       7       // 

/* OCR2RBL - Output Compare RB Register Low */
#define    OCR2RB_0        0       // 
#define    OCR2RB_1        1       // 
#define    OCR2RB_2        2       // 
#define    OCR2RB_3        3       // 
#define    OCR2RB_4        4       // 
#define    OCR2RB_5        5       // 
#define    OCR2RB_6        6       // 
#define    OCR2RB_7        7       // 

/* OCR2SBH - Output Compare SB Register High */
#define    OCR2SB_8        0       // 
#define    OCR2SB_9        1       // 
#define    OCR2SB_10       2       // 
#define    OCR2SB_11       3       // 

/* OCR2SBL - Output Compare SB Register Low */
#define    OCR2SB_0        0       // 
#define    OCR2SB_1        1       // 
#define    OCR2SB_2        2       // 
#define    OCR2SB_3        3       // 
#define    OCR2SB_4        4       // 
#define    OCR2SB_5        5       // 
#define    OCR2SB_6        6       // 
#define    OCR2SB_7        7       // 

/* OCR2RAH - Output Compare RA Register High */
#define    OCR2RA_8        0       // 
#define    OCR2RA_9        1       // 
#define    OCR2RA_10       2       // 
#define    OCR2RA_11       3       // 

/* OCR2RAL - Output Compare RA Register Low */
#define    OCR2RA_0        0       // 
#define    OCR2RA_1        1       // 
#define    OCR2RA_2        2       // 
#define    OCR2RA_3        3       // 
#define    OCR2RA_4        4       // 
#define    OCR2RA_5        5       // 
#define    OCR2RA_6        6       // 
#define    OCR2RA_7        7       // 

/* OCR2SAH - Output Compare SA Register High */
#define    OCR2SA_8        0       // 
#define    OCR2SA_9        1       // 
#define    OCR2SA_10       2       // 
#define    OCR2SA_11       3       // 

/* OCR2SAL - Output Compare SA Register Low */
#define    OCR2SA_0        0       // 
#define    OCR2SA_1        1       // 
#define    OCR2SA_2        2       // 
#define    OCR2SA_3        3       // 
#define    OCR2SA_4        4       // 
#define    OCR2SA_5        5       // 
#define    OCR2SA_6        6       // 
#define    OCR2SA_7        7       // 

/* POM2 - PSC 2 Output Matrix */
#define    POMV2A0         0       // Output Matrix Output A Ramp 0
#define    POMV2A1         1       // Output Matrix Output A Ramp 1
#define    POMV2A2         2       // Output Matrix Output A Ramp 2
#define    POMV2A3         3       // Output Matrix Output A Ramp 3
#define    POMV2B0         4       // Output Matrix Output B Ramp 0
#define    POMV2B1         5       // Output Matrix Output B Ramp 2
#define    POMV2B2         6       // Output Matrix Output B Ramp 2
#define    POMV2B3         7       // Output Matrix Output B Ramp 3

/* PSOC2 - PSC2 Synchro and Output Configuration */
#define    POEN2A          0       // PSCOUT20 Output Enable
#define    POEN2C          1       // PSCOUT22 Output Enable
#define    POEN2B          2       // PSCOUT21 Output Enable
#define    POEN2D          3       // PSCOUT23 Output Enable
#define    PSYNC2_0        4       // Synchronization Out for ADC Selection
#define    PSYNC2_1        5       // Synchronization Out for ADC Selection
#define    POS22           6       // PSC 2 Output 22 Select
#define    POS23           7       // PSC 2 Output 23 Select

/* PIM2 - PSC2 Interrupt Mask Register */
#define    PEOPE2          0       // End of Cycle Interrupt Enable
#define    PEOEPE2         1       // End of Enhanced Cycle Interrupt Enable
#define    PEVE2A          3       // External Event A Interrupt Enable
#define    PEVE2B          4       // External Event B Interrupt Enable
#define    PSEIE2          5       // PSC 2 Synchro Error Interrupt Enable

/* PIFR2 - PSC2 Interrupt Flag Register */
#define    PEOP2           0       // End of PSC2 Interrupt
#define    PRN20           1       // Ramp Number
#define    PRN21           2       // Ramp Number
#define    PEV2A           3       // External Event A Interrupt
#define    PEV2B           4       // External Event B Interrupt
#define    PSEI2           5       // PSC 2 Synchro Error Interrupt
#define    POAC2A          6       // PSC 2 Output A Activity
#define    POAC2B          7       // PSC 2 Output A Activity

/* PASDLY2 - Analog Synchronization Delay Register */
#define    PASDLY2_0       0       // 
#define    PASDLY2_1       1       // 
#define    PASDLY2_2       2       // 
#define    PASDLY2_3       3       // 
#define    PASDLY2_4       4       // 
#define    PASDLY2_5       5       // 
#define    PASDLY2_6       6       // 
#define    PASDLY2_7       7       // 

/* PCNFE2 - PSC 2 Enhanced Configuration Register */
#define    PISEL2B1        0       // 
#define    PISEL2A1        1       // 
#define    PELEV2B1        2       // 
#define    PELEV2A1        3       // 
#define    PBFM21          4       // 
#define    PASDLK20        5       // 
#define    PASDLK21        6       // 
#define    PASDLK22        7       // 


/* ***** TIMER_COUNTER_1 ************** */
/* TIMSK1 - Timer/Counter Interrupt Mask Register */
#define    TOIE1           0       // Timer/Counter1 Overflow Interrupt Enable
#define    ICIE1           5       // Timer/Counter1 Input Capture Interrupt Enable

/* TIFR1 - Timer/Counter Interrupt Flag register */
#define    TOV1            0       // Timer/Counter1 Overflow Flag
#define    ICF1            5       // Input Capture Flag 1

/* TCCR1B - Timer/Counter1 Control Register B */
#define    CS10            0       // Prescaler source of Timer/Counter 1
#define    CS11            1       // Prescaler source of Timer/Counter 1
#define    CS12            2       // Prescaler source of Timer/Counter 1
#define    WGM13           4       // Waveform Generation Mode
#define    ICES1           6       // Input Capture 1 Edge Select
#define    ICNC1           7       // Input Capture 1 Noise Canceler


/* ***** BOOT_LOAD ******************** */
/* SPMCSR - Store Program Memory Control Register */
#define    SPMEN           0       // Store Program Memory Enable
#define    PGERS           1       // Page Erase
#define    PGWRT           2       // Page Write
#define    BLBSET          3       // Boot Lock Bit Set
#define    RWWSRE          4       // Read While Write section read enable
#define    SIGRD           5       // Signature Row Read
#define    RWWSB           6       // Read While Write Section Busy
#define    SPMIE           7       // SPM Interrupt Enable



/* ***** LOCKSBITS ******************************************************** */
#define    LB1             0       // Lock bit
#define    LB2             1       // Lock bit
#define    BLB01           2       // Boot Lock bit
#define    BLB02           3       // Boot Lock bit
#define    BLB11           4       // Boot lock bit
#define    BLB12           5       // Boot lock bit


/* ***** FUSES ************************************************************ */
/* LOW fuse bits */
//#define  CKSEL0          0       // Select Clock Source
//#define  CKSEL1          1       // Select Clock Source
//#define  CKSEL2          2       // Select Clock Source
//#define  CKSEL3          3       // Select Clock Source
#define    SUT0            4       // Select start-up time
#define    SUT1            5       // Select start-up time
#define    CKOUT           6       // Clock Output
#define    CKDIV8          7       // Divide clock by 8

/* HIGH fuse bits */
#define    BOOTRST         0       // Select Reset Vector
#define    BOOTSZ0         1       // Select Boot Size
#define    BOOTSZ1         2       // Select Boot Size
#define    EESAVE          3       // EEPROM memory is preserved through chip erase
#define    WDTON           4       // Watchdog timer always on
#define    SPIEN           5       // Enable Serial programming and Data Downloading
#define    DWEN            6       // debugWIRE Enable
#define    RSTDISBL        7       // External Reset Disable

/* EXTENDED fuse bits */
#define    BODLEVEL0       0       // Brown-out Detector trigger level
#define    BODLEVEL1       1       // Brown-out Detector trigger level
#define    BODLEVEL2       2       // Brown out detector trigger level
#define    PSCINRB         3       // PSC2 & PSC0 Input Reset Behavior
#define    PSCRV           4       // PSCOUT Reset Value
#define    PSC0RB          5       // PSC0 Reset Behaviour
#define    PSC2RBA         6       // PSC2 Rest Behavior for out OUT22 & 23
#define    PSC2RB          7       // PSC2 Reset Behaviour



/* ***** CPU REGISTER DEFINITIONS ***************************************** */
#define    XH              r27
#define    XL              r26
#define    YH              r29
#define    YL              r28
#define    ZH              r31
#define    ZL              r30



/* ***** DATA MEMORY DECLARATIONS ***************************************** */
#define    FLASHEND        0x1fff  // Note: Byte address
#define    IOEND           0x00ff
#define    SRAM_START      0x0100
#define    SRAM_SIZE       256
#define    RAMEND          0x01ff
#define    XRAMEND         0x0000
#define    E2END           0x01ff
#define    EEPROMEND       0x01ff
#define    EEADRBITS       9



/* ***** BOOTLOADER DECLARATIONS ****************************************** */
#define    NRWW_START_ADDR 0xc00
#define    NRWW_STOP_ADDR  0xfff
#define    RWW_START_ADDR  0x0
#define    RWW_STOP_ADDR   0xbff
#define    PAGESIZE        32
#define    FIRSTBOOTSTART  0xf80
#define    SECONDBOOTSTART 0xf00
#define    THIRDBOOTSTART  0xe00
#define    FOURTHBOOTSTART 0xc00
#define    SMALLBOOTSTART  FIRSTBOOTSTART
#define    LARGEBOOTSTART  FOURTHBOOTSTART

#endif /* ENABLE_BIT_DEFINITIONS */



/* ***** INTERRUPT VECTORS ************************************************ */
#define    RESET_vect      (0x00)  // External Pin, Power-on Reset, Brown-out Reset, Watchdog Reset and JTAG AVR Reset
#define    PSC_CAPTURE2_vect (0x02)  // PSC2 Capture Event
#define    PSC_END_CYCLE2_vect (0x04)  // PSC2 End Cycle
#define    PSC_EEND_CYCLE2_vect (0x06)  // PSC2 End Of Enhanced Cycle
#define    PSC_CAPTURE0_vect (0x08)  // PSC0 Capture Event
#define    PSC_EEND_CYCLE0_vect (0x0a)  // PSC0 End Cycle
#define    PSC_END_CYCLE0_vect (0x0c)  // PSC0 End Of Enhanced Cycle
#define    ANA_COMP1_vect  (0x0e)  // Analog Comparator 1
#define    ANA_COMP2_vect  (0x10)  // Analog Comparator 2
#define    ANA_COMP3_vect  (0x12)  // Analog Comparator 3
#define    INT0_vect       (0x14)  // External Interrupt Request 0
#define    TIMER1_CAPT_vect (0x16)  // Timer/Counter1 Capture Event
#define    TIMER1_OVF_vect (0x18)  // Timer/Counter1 Overflow
#define    ADC_vect        (0x1a)  // ADC Conversion Complete
#define    INT1_vect       (0x1c)  // External Interrupt Request 1
#define    SPI_STC_vect    (0x1e)  // SPI Serial Transfer Complet
#define    INT2_vect       (0x20)  // External Interrupt Request 2
#define    WDT_vect        (0x22)  // Watchdog Timeout Interrupt
#define    EE_RDY_vect     (0x24)  // EEPROM Ready
#define    SPM_RDY_vect    (0x26)  // Store Program Memory Read



#endif /* __IOPWM81_H (define part) */

#pragma language=default

#endif  /* __IOPWM81_H (SFR part)*/

/* ***** END OF FILE ****************************************************** */
