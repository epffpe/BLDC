//! //! Copyright (c) 2009 Atmel.
//!  This program uses a loop to  :
//! - monitor the temperature sensor
//! - calculate the Vref which should be equal to the real  internal Vref
/

//_____  I N C L U D E S ___________________________________________________
#include "config.h"
#include "iopwm81.h"
#include "my_print.h"

//_____ D E C L A R A T I O N S ____________________________________________
    
#define HIGHBYTE(v) ((unsigned char) (((unsigned int) (v)) >> 8));
#define LOWBYTE(v) ((unsigned char) (v));

int main(void)
{
unsigned char  gain, offset, temp, vref_amb_low, vref_hot_low,vref_amb_high, vref_hot_high,result ;
unsigned int vref_recalc,vref_amb, vref_hot, n;
char   g, i;  
float a,b;

  PORTB= 0x00;
  DDRB=0xC7;
  ADCSRA |= 0x80;/* ADEN=1 */
  ADMUX |=0x80 ; /*Vref=2.56V */
  ADMUX &= ~0x2F;
  ADMUX |=0x0C; /* MUX to Temp sensor */
  ADCSRB =0x80; /* ADC High speed + fre running*/
  ADCSRA |=0x04 ; /* prescaler /16 */
  ADCSRA |= (1<<ADSC); /* first conversion  */
  
  while (SPMEN==1);
  
  asm("LDI R17,$00") ;/* Beginning of LPM sequence to read the Temp. sensor OFFSET in Signature Row */
  asm("LDI R16,$05");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1B, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);  
  offset=GPIOR2;  /* return of Temp. sensor OFFSET in Signature Row */
  
   
  asm("LDI R17,$00") ;/*Beginning of LPM sequence to read the Temp. sensor GAIN in Signature Row */
  asm("LDI R16,$07");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1A, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);    
  gain=GPIOR1; /* return of Temp. sensor GAIN in Signature Row */
  
  asm("LDI R17,$00") ;/*Beginning of LPM sequence to read the Vref. Amb.(low Byte) in Signature Row  */
  asm("LDI R16,$3C");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1A, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);    
  vref_amb_low=GPIOR1; /* return of Vref. Amb. Low Byte in Signature Row */
  
  asm("LDI R17,$00") ;/*Beginning of LPM sequence to read the Vref. Amb.(High Byte) in Signature Row   */
  asm("LDI R16,$3D");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1A, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);    
  vref_amb_high=GPIOR1;  /* return of Vref. Amb. High Byte in Signature Row */
  
  asm("LDI R17,$00") ;/*Beginning of LPM sequence to read the Vref. Hot(low Byte) in Signature Row   */
  asm("LDI R16,$3E");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1A, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);    
  vref_hot_low=GPIOR1;/* return of Vref. Hot Low Byte in Signature Row */
 
  asm("LDI R17,$00") ;/*Beginning of LPM sequence to read the Vref. Hot(High Byte) in Signature Row  */
  asm("LDI R16,$3F");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1A, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);    
  vref_hot_high=GPIOR1; /* return of Vref. Hot High Byte in Signature Row */
 
  vref_hot= (vref_hot_high *256) + vref_hot_low;
  vref_amb = (vref_amb_high * 256) + vref_amb_low;  
  a=(vref_hot - vref_amb)*100;
  a = a / 0x50;
  b= vref_amb - ((a * 0x19)/100);

  while(1)
    {
      
    while (ADIF == 0);
    ADCSRA |=0x10;  /* reset ADIF */
    temp =ADCL;
    result =(ADCH<<8);
    result = result | temp;
    result = result - (273+25-offset);
    temp = gain / 128;
    result = result * temp;
    temp = result +25;    
 
    putchar(0x54);putchar(0x3D);print_hex(temp);/* T=... temperature measurement in hex format*/
    
    for(i=1;i<100;i++);   putchar(0x0D);  for(i=1;i<100;i++);  putchar(0x0A);
    
    vref_recalc = (((a * temp)/100) + b) ;  /* Vref. recalculated versus the temperature measurement */
  
    putchar(0x41);putchar(0x3D);  
    print_hex(vref_amb_high);
    print_hex(vref_amb_low);
    for(i=1;i<100;i++);   putchar(0x0D);  for(i=1;i<100;i++);  putchar(0x0A); /* A=... Vref Amb. in hex format*/
   
    putchar(0x48);putchar(0x3D);
    print_hex(vref_hot_high);
    print_hex(vref_hot_low);

    for(i=1;i<100;i++);   putchar(0x0D);  for(i=1;i<100;i++);  putchar(0x0A); /* H=... Vref Hot. in hex format*/
   
    putchar(0x52);putchar(0x3D);  /* R=... Vref recalculated in hex format*/
    temp=HIGHBYTE(vref_recalc);
    print_hex (temp); 
    temp=LOWBYTE(vref_recalc);
    print_hex (temp);
    for(i=1;i<100;i++);   putchar(0x0D);  for(i=1;i<100;i++);  putchar(0x0A); /* R=... Vref Recalculated in hex format*/
    for(n=1;n<10000;n++)
      {
      for(i=1;i<100;i++);/* Delay to improve display in Hyperterminal */
      }
    ADMUX |=0x0C;
    ADCSRA |= (1<<ADSC); /* Starts a new conversion on Temp. sensor */
    }
}



