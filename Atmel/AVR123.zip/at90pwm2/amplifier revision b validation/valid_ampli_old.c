//! //! Copyright (c) 2009 Atmel.
//!  This program uses a loop to do :
//! - 3 ADC conversions on AMP0
//! - then 2 conversions on ADC2
//! - checks that the results of the 3 AMP0 ADC are within +-10%

//_____  I N C L U D E S ___________________________________________________
#include "config.h"
#include "iopwm81.h"
#include "my_print.h"

//_____ D E C L A R A T I O N S ____________________________________________
    
#define HIGHBYTE(v) ((unsigned char) (((unsigned int) (v)) >> 8));
#define LOWBYTE(v) ((unsigned char) (v));

int main(void)
{
unsigned char  gain, offset, temp, vref_amb_low, vref_hot_low,vref_amb_high, vref_hot_high ;
unsigned int vref_recalc,vref_amb, vref_hot;
char   g, i;  
unsigned char  result;
float a,b;

  PORTB= 0x00;
  DDRB=0xC7;
  ADCSRA |= 0x80;/* ADEN=1 */
  ADMUX |=0x80 ; /*Vref=2.56V */
  ADMUX &= ~0x2F;
  ADMUX |=0x0C; /* MUX to Temp sensor */
  ADCSRB =0x80; /* ADC High speed + fre running*/
  ADCSRA |=0x04 ; /* prescaler /16 */
  ADCSRA |= (1<<ADSC); /* first conversion  */
  
  while (SPMEN==1);
  
  asm("LDI R17,$00") ;/* Beginning of LPM sequence to read the Temp. sensor OFFSET in Signature Row */
  asm("LDI R16,$05");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1B, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);  
  offset=GPIOR2;  /* return of Temp. sensor OFFSET in Signature Row */
  
   
  asm("LDI R17,$00") ;/*Beginning of LPM sequence to read the Temp. sensor GAIN in Signature Row */
  asm("LDI R16,$07");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1A, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);    
  gain=GPIOR1; /* return of Temp. sensor GAIN in Signature Row */
  
  asm("LDI R17,$00") ;/*Beginning of LPM sequence to read the Vref. Amb.(low Byte) in Signature Row  */
  asm("LDI R16,$3C");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1A, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);    
  vref_amb_low=GPIOR1; /* return of Vref. Amb. Low Byte in Signature Row */
  
  asm("LDI R17,$00") ;/*Beginning of LPM sequence to read the Vref. Amb.(High Byte) in Signature Row   */
  asm("LDI R16,$3D");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1A, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);    
  vref_amb_high=GPIOR1;  /* return of Vref. Amb. High Byte in Signature Row */
  
  asm("LDI R17,$00") ;/*Beginning of LPM sequence to read the Vref. Hot(low Byte) in Signature Row   */
  asm("LDI R16,$3E");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1A, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);    
  vref_hot_low=GPIOR1;/* return of Vref. Hot Low Byte in Signature Row */
 
  asm("LDI R17,$00") ;/*Beginning of LPM sequence to read the Vref. Hot(High Byte) in Signature Row  */
  asm("LDI R16,$3F");
  asm("MOV R31,R17") ;/*  */
  asm("MOV R30,R16") ;/* ;move adress to z pointer (R31=ZH R30=ZL)*/
  SPMCSR=0x21;
  asm("LPM") ;/* ;Store program memory*/
  asm("MOV R16, R0") ;/* ;Store return value (1byte->R16 register)*/
  asm("OUT 0x1A, R16") ;/* ;Store return value (1byte->R16 register)*/
  while (SPMEN==1);    
  vref_hot_high=GPIOR1; /* return of Vref. Hot High Byte in Signature Row */
 
  vref_hot= (vref_hot_high *256) + vref_hot_low;
  vref_amb = (vref_amb_high * 256) + vref_amb_low;  
  a=(vref_hot - vref_amb)/ 80;
  b= vref_amb- (a*25);

  while(1)
    {
    while (ADIF == 0); /* waits for the end of conversion */
    ADCSRA |=0x10;  /* reset ADIF */
    result = (((ADCH<<8) | ADCL)- (273+25-offset));
    g = gain / 128;
    result = (result * g) ;
    temp = result +25;/* temperature measurement in hex format*/
    
 
    putchar(0x54);putchar(0x3D);print_hex(temp);/* T=... temperature measurement in hex format*/
    
    for(i=1;i<100;i++);   putchar(0x0D);  for(i=1;i<100;i++);  putchar(0x0A);
    vref_recalc = (a * temp) + b;  /* Vref. recalculated versus the temperature measurement */
  
    putchar(0x41);putchar(0x3D);  
     print_hex(vref_amb_high);
     print_hex(vref_amb_low);
    for(i=1;i<100;i++);   putchar(0x0D);  for(i=1;i<100;i++);  putchar(0x0A); /* A=... Vref Amb. in hex format*/
   
    putchar(0x48);putchar(0x3D);
     print_hex(vref_hot_high);
     print_hex(vref_hot_low);
//    temp=HIGHBYTE(vref_hot);
//    print_hex (temp); 
//    temp=LOWBYTE(vref_hot);
//    print_hex (temp); 
    for(i=1;i<100;i++);   putchar(0x0D);  for(i=1;i<100;i++);  putchar(0x0A); /* H=... Vref Amb. in hex format*/
   
    putchar(0x52);putchar(0x3D);  
    temp=HIGHBYTE(vref_recalc);
    print_hex (temp); 
    temp=LOWBYTE(vref_recalc);
    print_hex (temp);
    for(i=1;i<100;i++);   putchar(0x0D);  for(i=1;i<100;i++);  putchar(0x0A); /* R=... Vref Amb. in hex format*/
    
    ADMUX |=0x0C;
    ADCSRA |= (1<<ADSC); /* Starts a new conversion on Temp. sensor */
    }
}



