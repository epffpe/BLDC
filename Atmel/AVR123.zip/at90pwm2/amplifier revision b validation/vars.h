#define START_RAM_VARS	0x0100

#ifdef _C_SRC_

	extern volatile unsigned int i_pk_corr;
	extern volatile unsigned int i_pk_min;
	extern volatile unsigned int i_pk_max;
	extern volatile unsigned int u_buck_min;
	extern volatile unsigned int u_buck_max;
#else
#ifndef __vars_s90__
	
	EXTERN	i_pk_corr
		
	EXTERN i_pk_min
	EXTERN i_pk_max
	EXTERN u_buck_min
	EXTERN u_buck_max

	
#endif
#endif




