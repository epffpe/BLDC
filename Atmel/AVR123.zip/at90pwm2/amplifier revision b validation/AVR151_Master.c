//***************************************************************************
// A P P L I C A T I O N   N O T E   F O R   T H E   A V R   F A M I L Y
//
// Number               : AVR151
// File Name            : "avr151_Master.c"
// Title                : Setup and Use The SPI
// Date                 : 00.09.20
// Version              : 1.0
// Target MCU           : Any AVR with SPI
//
// DESCRIPTION
// This Application note shows how to enable and use the on-board SPI of the 
// AVR's in Master- and in Slave-Mode. 
//
// This file contains the code of all the examples. To switch between the examples
// you will have to enable the call of the corresponding routines.
// (see the comments in the main program at the bottom)
//
// Modified 2004-10-25 RAA
//
//**************************************************************************
#include "config.h"
#include "inavr.h"
#include "ioavr.h"
#include "iopwm81.h"

#include "lib_mcu/psc/psc_drv.h"

char*    TextString    = "AVR communicating via the SPI"+0x00;
extern Psc_comparison_values    *PtrToStrChar;                 	// Pointer to certain Character in String
extern  Psc_comparison_values gs_pfc_comparison_values;
//Psc_comparison_values gs_pfc_comparison_values;
//Psc_comparison_values * PtrToStrChar;                  	// Pointer to certain Character in String
char     ClearToSend2   = 1;             	// String send complete bit

// Interrupt Routine Master Mode (interrupt controlled)
/*
#pragma vector=SPI_STC_vect
__interrupt void ISR_SPI (void)
{
        PtrToStrChar++;                 	// Point to next Char in String
        if (PtrToStrChar != 0)         	// if end not reached
        {
                SPDR  = (PtrToStrChar->ontime0);  	// send Character
        }
        else ClearToSend2 = 1;           	// if end reached enable transmission of next String
}
*/
// Intialization Routine Master Mode (polling)
void Init_Master (void)
{
        volatile char IOReg;
        // set PB4(/SS), PB5(MOSI), PB7(SCK) as output 
       DDRB  = (1<<DDB4)|(1<<DDB5)|(1<<DDB6);
//      DDRD  = (1<<DDD0);  
        // enable SPI in Master Mode with SCK = CK/4
        SPCR    = (1<<SPE)|(1<<MSTR);
        IOReg   = SPSR;                 	// clear SPIF bit in SPSR
        IOReg   = SPDR;
}

// Intialization Routine Master Mode (interrupt controlled)
void Init_Master_IntContr (void)
{
        volatile char IOReg;
        // set PB4(/SS), PB5(MOSI), PB7(SCK) as output 
       DDRB  = (1<<DDB4)|(1<<DDB5)|(1<<DDB6);
//       DDRD  = (1<<DDD0);  
        // enable SPI Interrupt and SPI in Master Mode with SCK = CK/16
        SPCR  = (1<<SPIE)|(1<<SPE)|(1<<MSTR)|(1<<SPR0);
        IOReg   = SPSR;                 	// clear SPIF bit in SPSR
        IOReg   = SPDR;
        __enable_interrupt();
}



// Sending Routine Master Mode (polling)
void Master_Send (void)
{
//        while   (PtrToStrChar != 0)            // if not end of String
//        {
//                SPDR  = (PtrToStrChar->ontime0);          // send Character
  SPDR = gs_pfc_comparison_values.ontime0;
                while (!(SPSR & (1<<SPIF)));    // wait until Char is sent 
//                PtrToStrChar++;                 // Point to next char in String
                //}        
}


// Sending Routine Master Mode (interrupt controlled)
void Master_Send_IntContr (void)
{
        if (ClearToSend2 == 1){                  // if no transmission is in progress
                SPDR = (PtrToStrChar->ontime0);           // sending first Char of new String
                ClearToSend2 = 0;                // block initiation of new transmissions
        }
}



