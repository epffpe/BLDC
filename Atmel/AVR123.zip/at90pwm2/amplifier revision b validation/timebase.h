/**********************************************************************************************************************/
/* Firmware HID PTm20 ballast with Atmel AT90PWM3					          																									*/
/* ---------------------------------------------					          																									*/
/* Global Fullbridge Platform HID				         																																			*/
/*									          																																												*/
/* (c) Osram GmbH								         																																							*/
/*     E&C D / PT-M								          																																					*/
/*     Hellabrunner Strasse 1							          																																	*/
/*     81536 M�nchen								          																																				*/
/*									          																																												*/
/* timebase.h: Updates timebase flags for ms, s, min and hours																												*/
/*									          																																												*/
/* Initial Version 1.0 03/2008 Maximilian Schmidl								          																						*/
/*									          																																												*/
/* $Id:: timebase.h 146 2008-07-28 13:08:32Z m.schmidl             $																									*/
/*									          																																												*/
/**********************************************************************************************************************/

#ifdef _C_SRC_

	extern void timebase(void);

#else
#ifndef __timebase_s90__
	EXTERN integrator_1ms
	EXTERN timebase
#endif

#endif

