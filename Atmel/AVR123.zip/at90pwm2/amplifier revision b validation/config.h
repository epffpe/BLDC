//! @file $RCSfile: config.h,v $
//!
//! Copyright (c) 2004 Atmel.
//!
//! Please read file license.txt for copyright notice.
//!
//! @brief This file contains the low level definitions for the megaballsat Reference Design use
//!
//! @version $Revision: 1.7 $ $Name: megaballast-refd-3_0_0 $
//!
//! @todo
//! @bug

#ifndef CONFIG_H
#define CONFIG_H

//_____  I N C L U D E S ___________________________________________________
#include "lib_mcu/compiler.h"
//#include "lib_mcu/mcu.h"
#include "iopwm81.h"

#include "inavr.h"
//_____ M A C R O S ________________________________________________________

//#define EUSART_USED_FOR_DALI

//_____ D E F I N I T I O N S ______________________________________________
//! @defgroup Application_defines_configuration Application Defines Configuration
//! Defines allowing to init the Application with the wanted configuration
//! @{

   //! @defgroup PSC_defines_configuration PSC Defines Configuration
   //! Defines allowing to init the PSC with the wanted configuration
   //! @{

      //! @defgroup PSC0_defines PSC0 Defines
      //! PSC0 Defines
      //! @{
//#define USE_PSC0

         //! @defgroup PSC0_defines_configuration PSC0 Defines Configuration
         //! Defines allowing to init the PSC0 with the wanted configuration
         //! @{

#define PSC0_PLL_FREQUENCY                     64 //!< 0: use I/O clk          32: 32MHz PLL     64: 64MHz PLL
#define PSC0_OUTPUT_SELECTION                   1 //!< 0: none   1: pscout00    2: pscout01       3: pscout00 and pscout01
#define PSC0_ACTIVE_STATE                       1 //!< 0: active low            1: active high
#define PSC0_RAMP_MODE                          1 //!< 0: centered mode         1: One ramp mode  2: Two ramps mode  4: For ramps mode
#define PSC0_FIFTY_PERCENT_MODE                 0 //!< 0: no fifty percent mode 1: fifty percent mode
#define PSC0_SYMETRICAL_FLANK_WIDTH_MODULATION  0 //!< 0: no symetrical FWM     1: symetrical FWM
#define PSC0_AUTOLOCK_MODE                      0 //!< 0: no autolock mode      1: autolock mode
#define PSC0_PRESCALER_DIVIDER                  0 //!< 0: no divider            4: divide by 4   16: divide by 16   64: divide by 64
         //! @}

      //! @}

      //! @defgroup PSC1_defines PSC1 Defines
      //! PSC1 Defines
      //! @{
//#define USE_PSC1

         //! @defgroup PSC1_defines_configuration PSC1 Defines Configuration
         //! Defines allowing to init the PSC1 with the wanted configuration
         //! @{

         //! PSC1 is not used in this application
#define PSC1_PLL_FREQUENCY                     64 //!< 0: use I/O clk          32: 32MHz PLL     64: 64MHz PLL
#define PSC1_OUTPUT_SELECTION                   1 //!< 0: none   1: pscout10    2: pscout11       3: pscout10 and pscout11
#define PSC1_ACTIVE_STATE                       1 //!< 0: active low            1: active high
#define PSC1_RAMP_MODE                          1 //!< 0: centered mode         1: One ramp mode  2: Two ramps mode  4: For ramps mode
#define PSC1_FIFTY_PERCENT_MODE                 0 //!< 0: no fifty percent mode 1: fifty percent mode
#define PSC1_SYMETRICAL_FLANK_WIDTH_MODULATION  0 //!< 0: no symetrical FWM     1: symetrical FWM
#define PSC1_AUTOLOCK_MODE                      0 //!< 0: no autolock mode      1: autolock mode
#define PSC1_PRESCALER_DIVIDER                  0 //!< 0: no divider            4: divide by 4   16: divide by 16   64: divide by 64
         //! @}

      //! @}

      //! @defgroup PSC2_defines PSC2 Defines
      //! PSC2 Defines
      //! @{
#define USE_PSC2

         //! @defgroup PSC2_defines_configuration PSC2 Defines Configuration
         //! Defines allowing to init the PSC2 with the wanted configuration
         //! @{

#define PSC2_PLL_FREQUENCY                     64 //!< 0: use I/O clk          32: 32MHz PLL     64: 64MHz PLL
#define PSC2_OUTPUT_SELECTION                   1 //!< 0: none   1: pscout20    2: pscout21       3: pscout20 and pscout21
#define PSC2_ACTIVE_STATE                       1 //!< 0: active low            1: active high
#define PSC2_RAMP_MODE                          1 //!< 0: centered mode         1: One ramp mode  2: Two ramps mode  4: For ramps mode
#define PSC2_FIFTY_PERCENT_MODE                 0 //!< 0: no fifty percent mode 1: fifty percent mode
#define PSC2_SYMETRICAL_FLANK_WIDTH_MODULATION  0 //!< 0: no symetrical FWM     1: symetrical FWM
#define PSC2_AUTOLOCK_MODE                      0 //!< 0: no autolock mode      1: autolock mode
#define PSC2_PRESCALER_DIVIDER                  0 //!< 0: no divider            4: divide by 4   16: divide by 16   64: divide by 64
         //! @}

      //! @}

   //! @}

   //! @defgroup ADC_defines_configuration_values ADC Defines Configuration Values
   //! Defines allowing to init the ADC with the wanted configuration
   //! @{
#define USE_ADC

#define ADC_RIGHT_ADJUST_RESULT                 1 //!< 0: Result left adjusted  1: Result right adjusted
#define ADC_INTERNAL_VREF                       3 //!< 0: External Vref   3: Internal Vref+outputVref    1: Internal Vref  2: Vref is connected to Vcc
#define ADC_IT                                  0 //!< 0: No ADC End of Conv IT 1: ADC End of conversion generates an IT
#define ADC_PRESCALER                           16 //!< 2, 4, 8, 16, 32, 64, 128  : The input ADC frequency is the system clock frequency divided by the const value
   //! @}

   //! @defgroup Amplifiers_defines_configuration_values Amplifiers Defines Configuration Values
   //! Defines allowing to init the Amplifiers with the wanted configuration
   //! @{

      //! @defgroup Amplifier0_defines_configuration_values Amplifier0 Defines Configuration Values
      //! Defines allowing to init the Amplifier 0 with the wanted configuration
      //! @{
#define USE_AMP0

#define AMP0_INPUT_SHUNT                        0 //!< 0: Disbale input shunt   1: Enable input shunt
#define AMP0_GAIN                               5 //!< 5: Gain5    10: Gain10  20: Gain20  40: gain40
#define AMP0_CLOCK                              3 //!< 0: ADCclk/8E 1: PSC0     2: PSC1     3: PSC2
      //! @}

      //! @defgroup Amplifier1_defines_configuration_values Amplifier1 Defines Configuration Values
      //! Defines allowing to init the Amplifier 1 with the wanted configuration
      //! @{
//#define USE_AMP1

#define AMP1_INPUT_SHUNT                        0 //!< 0: Disbale input shunt   1: Enable input shunt
#define AMP1_GAIN                              10 //!< 5: Gain5    10: Gain10  20: Gain20  40: gain40
#define AMP1_CLOCK                              0 //!< 0: ADCclk/8E 1: PSC0     2: PSC1     3: PSC2
      //! @}

   //! @}

   //! @defgroup Comparators_defines_configuration_values Comparators Defines Configuration Values
   //! Defines allowing to init the Comparators with the wanted configuration
   //! @{

      //! @defgroup Comparator0_defines_configuration_values Comparator0 Defines Configuration Values
      //! Defines allowing to init the Comparator 0 with the wanted configuration
      //! @{
//#define USE_COMP0

#define COMPARATOR0_IT                          1 //!< 0: No Comparator 0 IT     1: Comparator 0 event generates an IT
#define COMPARATOR0_IT_EVENT                    2 //!< 0: IT on toggle  2: IT on falling edge  3: IT on rising edge
#define COMPARATOR0_NEGATIVE_INPUT              3 //!< 0: Vref/6.40  1: Vref/3.20  2: Vref/2.13  3: Vref/1.60  4:ACMPM pin  5: DAC result
      //! @}

      //! @defgroup Comparator1_defines_configuration_values Comparator1 Defines Configuration Values
      //! Defines allowing to init the Comparator 1 with the wanted configuration
      //! @{
//#define USE_COMP1

#define COMPARATOR1_IT                          0 //!< 0: No Comparator 1 IT 1: Comparator 0 event generates an IT
#define COMPARATOR1_IT_EVENT                    0 //!< 0: IT on toggle  2: IT on falling edge  3: IT on rising edge
#define COMPARATOR1_NEGATIVE_INPUT              0 //!< 0: Vref/6.40  1: Vref/3.20  2: Vref/2.13  3: Vref/1.60  4:ACMPM pin  5: DAC result
      //! @}

      //! @defgroup Comparator2_defines_configuration_values Comparator2 Defines Configuration Values
      //! Defines allowing to init the Comparator 2 with the wanted configuration
      //! @{
//#define USE_COMP2

#define COMPARATOR2_IT                          0 //!< 0: No Comparator 2 IT 1: Comparator 0 event generates an IT
#define COMPARATOR2_IT_EVENT                    0 //!< 0: IT on toggle  2: IT on falling edge  3: IT on rising edge
#define COMPARATOR2_NEGATIVE_INPUT              2 //!< 0: Vref/6.40  1: Vref/3.20  2: Vref/2.13  3: Vref/1.60  4:ACMPM pin  5: DAC result
      //! @}

   //! @}

//! @}



//_____ F U N C T I O N S __________________________________________________

#endif  // CONFIG_H
