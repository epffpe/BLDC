#include "my_print.h"


void print_hex(unsigned char n)
{

   unsigned char i;
 
   i=n>>4;
   if(i>9) putchar(i-0x0A+'A');
   else putchar(i+'0');
   i=n&0x0F;
	
   if(i>9) putchar(i-0x0A+'A');
   else putchar(i+'0'); 

   
}

void print_int(unsigned int n)
{
   print_hex(n>>8);
    print_hex(n);

}
