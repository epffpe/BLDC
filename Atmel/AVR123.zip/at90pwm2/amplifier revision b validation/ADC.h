#ifdef _C_SRC_

extern unsigned int read_adc_16(void);  					// Reads the actual ADC_Channel stored in ADMUX,
                                        					

extern void start_conv(unsigned char admux_byte); // Starts a new AD conversion of the given Channel


void wait_for_adc_result(void);				  					// Waits until the ADIF is set by a finished conversion
#else

#ifndef __ADC_s90__
EXTERN	read_adc_16
EXTERN	start_conv
EXTERN	wait_for_adc_result
EXTERN	print_hex
#endif

#endif
