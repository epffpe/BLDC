

extern int putchar(int);
extern void soft_uart_init(void);

#define CRLF() (putchar(0x0D), putchar(0x0A))

void print_hex(unsigned char n);
void print_int(unsigned int n);
void print_str(unsigned char st[]);
