
//#ifdef _C_SRC_                  /***  Commutation timing registers ***/

//#else
    #define psc_reg_buff__r_ocrral 0
    #define psc_reg_buff__r_ocrrah 1
    #define psc_reg_buff__r_ocrrbl 2
    #define psc_reg_buff__r_ocrrbh 3
    #define psc_reg_buff__sizeof   4
//#endif