/*************************************** Setup run mode constants *****************************************************/
#define RUN_DT		  					180		// ns			// Deadtime after retrigger
#define RUN_TOFF							20000	// ns
#define RUN_TON_INIT					9200 	// ns 		// Initiale On-Zeit f�r


/*************************************** Debugging section ************************************************************/
#define DEBUG_LED_OUTPUT_EN										// enable debug-output


#define ENABLE_BIT_DEFINITIONS

#ifdef _C_SRC_
  #include "intrinsics.h"										// definition of intrinsic functions
  #pragma language=extended                 // enables non ANSI-C commands
#else
  COL 130                                   // Listing control: 130 columns
#endif

/***** Definitions for debugging purposes *****/

#define DEBUGFLAG						PORTB, 6					// Pin 27
#define DEBUG_LED         PORTB, 2


#define FB0_RIGHT_PORT			PORTB							
#define FB0_RIGHT_PORT_IN		PINB
#define LGI01_BIT						1									// Pin 3
#define HGI01_BIT						2									// Pin 4

#define FB0_LEFT_PORT		   	PORTB             // connected to HB drivers ("Bellomo mode" is used)
#define FB0_LEFT_PORT_IN		PINB
#define LGI00_BIT						7									// Pin 29
#define HGI00_BIT						0									// Pin 30


//--- derived definitions ---
//----------------------------------------------------------------------------------------------------------------------		
#define HGI01								FB0_RIGHT_PORT, HGI01_BIT					
#define HGI01_TOGGLE				FB0_RIGHT_PORT_IN, HGI01_BIT
#define LGI01								FB0_RIGHT_PORT, LGI01_BIT
#define LGI01_TOGGLE				FB0_RIGHT_PORT_IN, LGI01_BIT
#define HGI00								FB0_LEFT_PORT, HGI00_BIT
#define HGI00_TOGGLE				FB0_LEFT_PORT_IN, HGI00_BIT
#define LGI00								FB0_LEFT_PORT, LGI00_BIT
#define LGI00_TOGGLE				FB0_LEFT_PORT_IN, LGI00_BIT


/***** System clock generation ****/

#define CORECLOCK				12000000// Hz
#define PLLCLOCK   			(CORECLOCK*4)
#define ROOT_TIMEBASE				210			// �s 		// Main timing interrupt repetition time !!!

    																					// TODO : TO DO : Die Clockteiler in subs.h sind auf 100us optimiert, bei
    																					// 8Mhz w�re ein 104us Interrupt zu �berlegen, da der mit einem Teiler von
    																					// 64 gut zu realiesieren ist (13 Schritte)

/**********************************************************************************************************************/
/* ADC-Channels (ADMUX-values with Vref=2.56V, ADLAR = 1)																															*/
/**********************************************************************************************************************/
#define ADC_CH_CENTER				0xe2    //--- Pin19,    PB.5,   ADC5 ---
#define ADC_CH_AMP0					0xeb    //--- Pin26/23, PD.6/5, AMP0 (channel 11) ---
		
/*************************************** Setup ticks and flags ********************************************************/		
//--- Some ticks for timing ---
#define ticks 							GPIOR0						// uses special register for more efficient bit usage
#define TICK_1MS						ticks, 0					// Set every 1ms
#define TICK_5MS						ticks, 1					// Set every 5ms
#define TICK_50MS						ticks, 2					// Set every 50 ms
#define TICK_SEC						ticks, 3					// Set once per second
#define TICK_MIN						ticks, 4					// Set once per minutes



		
