#ifdef _C_SRC_
	extern void transition_to_run(void);
#endif