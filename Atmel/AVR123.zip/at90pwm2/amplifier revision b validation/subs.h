#ifdef _C_SRC_

	extern void led_send(ui8 val);

	extern void init_peripherals(void);
	extern void init_run(void);
	
	extern void Write_Data_to_LED_Buffer(ui8, void*); // ui8: Kanal (A0..BF -> Byte, C0..DF -> Integer)
	extern void Write_Char_to_LED_Buffer(ui8);			 	// ui8: Character

#else

#ifndef __subs_s90__
//extern	Write_Data_to_LED_Buffer;
#endif

#endif
