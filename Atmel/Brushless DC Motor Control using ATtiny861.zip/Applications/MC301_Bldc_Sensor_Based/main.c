//******************************************************************************
//!
//! @file $Id: main.c 2100 2008-09-25 13:01:59Z raubree $
//!
//! Copyright (c) 2008 Atmel.
//!
//! @brief Main module : It is based on an infinite loop
//!
//! @todo
//! @bug
//******************************************************************************

/* Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//_____  I N C L U D E S ___________________________________________________


#include "config.h"
#include "usi_twi_slave.h"
#include "bldc.h"
#include "TinyX61_macros.h"
#include "ushell_task.h"

/*
 * Before running this application:
 * Make sure CKDIV8 fuse is disabled.
 * Set PLL as clock source.
 */

volatile motorControlFlags_t mcFastFlags;
volatile U8 ControlMode;
volatile U16 SpeedMeasure;
volatile U16 timer_value;
volatile U16 new_measured_speed;
volatile Bool is_speed_to_read=FALSE;

// USI Handshake variables for USI Slave to TWI Master communication
Bool is_data_to_send=0;
Bool is_data_received=0;
unsigned char data_to_send;
unsigned char data_received;

U16 speed;
U16 current;
U8  direction;

volatile uint8_t hall;
 
//! Set_cpu_prescaler.
//!
//! This function write the CPU prescaler register to a define value
//!
//! @param U8 the precaler value to be written
//!
//! @return none.
//!
#ifndef __GNUC__
   #pragma optimize=none 
   void Set_cpu_prescaler(U8 x)
   {
      U8 save_int=SREG&0x80;
      Disable_interrupt();
      CLKPR=(1<<CLKPCE);
      CLKPR=x;
      if(save_int) { Enable_interrupt(); }
   }
#endif

void main(void)
{ 
  Clear_prescaler();
  PLLInit();
  PWMInit();
  HallSensorInit();

  ADCInit();

  // Init USI Handshake variables
  is_data_to_send=FALSE;
  is_data_received=FALSE;

  SpeedMeasure=0;
  is_speed_to_read=FALSE;
  
  // Initialize timer0 for Speed Measurement
  Timer0Init();
  
  PortsInit();
  
  // uShell init
  ushell_task_init();
  
  //Run Commutate() once to make sure that the right coils are activated.
  Commutate();

  //Enable interrupts. The rest will now be handled by the ADC and Pin change
  //interrupts.
  Enable_interrupt();
  
  for (;;) {
    if(ControlMode==MOTOR_CONTROL_CENTER)
    {
      if (mcFastFlags.state == STATE_RUN)
      {
        // Update Motor speed
        MotorSetDutyCycle(mcFastFlags.speed);
        // Start Speed measurement
        if(is_speed_to_read==TRUE)
          SpeedMeasurement();   
      }
      else
      {
        //Stop Motor
        MotorSetDutyCycle(0);
        mcFastFlags.speed=0;
      }
      
      // Decodes new Motor Control Center command
      ushell_task();
   
      // Manages new low level TWI data received
      if(is_data_received==FALSE)
      {
        if (USI_TWI_Data_In_Receive_Buffer())    //Something new of the USI ?
        {
          data_received=USI_TWI_Receive_Byte();
          is_data_received=TRUE;
        }
      }
    }
  }
}


void Commutate(void)
{
   uint8_t temp;
   //Read hall sensor inputs.
    temp = ( PINA & ((1 << PA5) | (1 << PA4) | (1 << PA1)) );
    hall = (((temp&0x30)>>3) | (temp&0x02)>>1);

    
  //Activate output pattern corresponding to current direction and position.
  if (mcFastFlags.direction == DIRECTION_FORWARD) {
    TCCR1E = commTableForward[hall];
  }
  else {
    TCCR1E = commTableReverse[hall];
  }
    
}

#pragma inline=forced
void SpeedMeasurement(void)
{
//   if (timer_value == 0) 
  //  {timer_value += 1 ;} // warning DIV by 0
/*
    new_measured_speed = K_SPEED / timer_value;
    if(new_measured_speed > 255) new_measured_speed = 255; // Variable saturation
    SpeedMeasure=(U16)new_measured_speed;
*/    
    is_speed_to_read=FALSE;
  
}

void PLLInit(void)
{
  //Enable fast peripheral clock (64MHz for Timer1).
  PLLCSR = (1 << PCKE);
}


void PWMInit(void)
{
 
  //Clear on up-counting.
  TCCR1A = (1 << COM1A1) | (0 << COM1A0) | (1 << PWM1A);

  //Set WGM to PWM6, dual slope mode.
  TCCR1D = (1 << WGM11) | (1 << WGM10);

  //Set top value.
  TC1_WRITE_10_BIT_REGISTER(OCR1C, PWM_TOP_VALUE);

  //Run timer at full speed.
  TCCR1B = (1 << CS10);
}


void HallSensorInit(void)
{
  //Enable pin change interrupts for PA1-PA4-PA5 (PCINT1-4-5).
  PCMSK0 = (1 << PCINT1) | (1 << PCINT4) | (1 << PCINT5);

  //Zero out PCMSK1, since it is initialized to a non-zero value.
  PCMSK1 = 1;

  //Enable pin change interrupt 1.
  GIMSK |= (1 << PCIE1);
}


void ADCInit(void)
{
  ADMUX = (0 << REFS1) | (0 << REFS0) | //VCC as voltage reference.
          (0 << ADLAR) |                //Right adjusted result.
          ADMUX_PA2;                    //ADC channel. MC301 rev B

  ADCSRB = (1 << REFS2) |               //Last reference selection bit.
           ADC_TS_FREERUNNING;          //Free running mode.

  ADCSRA = (1 << ADEN) |                //Enable.
           (1 << ADSC) |                //Start first conversion.
           (1 << ADATE) |               //Auto triggering.
           (1 << ADIE) |                //Enable interrupt.
           ADC_PRESCALER;
}


void PortsInit(void)
{
  //Set PWM pins as output. (PWM output is still controlled through TCCR1E register.)
  DDRB = (1 << PB0) | (1 << PB1) | (1 << PB2) | (1 << PB3) | (1 << PB4) | (1 << PB5)| (1 << PB6) ;
}

void TWInit(void)
{
  // Select the Port A as USI port
  USIPP|=(1<<USIPOS);
  // Own TWI slave address
  USI_TWI_Slave_Initialise( TWI_SLAVE_ADDRESS ); 
}

void MotorSetDutyCycle(U16 duty)
{
TC1_WRITE_10_BIT_REGISTER(OCR1A, duty);
}

#ifdef __GNUC__
  ISR(PCINT_vect)
#else
#pragma vector = PCINT0_vect
__interrupt void HallChangeISR()
#endif
{
   
  Commutate();

  //estimation speed on rising edge of Hall 1 (U')
  if (PINA&(1<<PORTA1))
  {
    if(is_speed_to_read==FALSE)
    {
      // Stop Timer
      TCCR0B &= ~((1<<CS02)|(1<<CS01) |(1<<CS00)); 
  
      // Read timer0 value
      TC0_READ_TCNT0(timer_value);
    }
    
    // Restart timer0
    TCCR0B = ((1<<CS02)|(0<<CS01) |(1<<CS00)); // Timer clock =
                                  // system clock /
                                  // 128 : 16�s
    TC0_WRITE_TCNT0(0x0);
        
    is_speed_to_read=FALSE;  // Wait for a period
  }
  else
  {
    is_speed_to_read=TRUE;
  }
}

#ifdef __GNUC__
  ISR(ADC_vect)
#else
#pragma vector = ADC_vect
__interrupt void ADCISR()
#endif
{
  U16 speedSetpoint;

  //Read ADC sample.
  speedSetpoint = ADC;

  if(speedSetpoint>=ADC_TWI)
  {
    ControlMode=MOTOR_CONTROL_CENTER;

    //  Clear ADC enable
    ADCSRA &= ~(1 << ADEN);
    //Disable interrupt.
    ADCSRA &= ~(1 << ADIE);              

    TWInit();
  }
  else
  {
    ControlMode=POTENTIOMETER;
    //Extract sign.
    if (speedSetpoint >= ((ADC_MAX + 1) / 2)) {
      mcFastFlags.direction = DIRECTION_FORWARD;
      speedSetpoint -= ((ADC_MAX + 1) / 2);
    }
    else {
      mcFastFlags.direction = DIRECTION_REVERSE;
      speedSetpoint = ((ADC_MAX) / 2) - speedSetpoint;
    }

    //Multiply speed setpoint by 2 to get full PWM range.
    speedSetpoint *= 2;

    MotorSetDutyCycle(speedSetpoint);
  }
}

void Timer0Init(void)
{
  TCCR0B = ((1<<CS02)|(0<<CS01) |(1<<CS00)); // Timer clock =
                                // system clock /
                                // 128 : 16�s
  TIFR |= (1<<TOV0); //Clear TOV0 / clear

  TC0_WRITE_TCNT0(0x0);
  //pending interrupts
  TIMSK |= (1<<TOIE0); //Enable Timer0
  //Overflow Interrupt
}

/**
  * @brief Timer0 Overflow for speed measurement
  * @pre configuration of timer 0
  * @post generate an overflow when the motor turns too slowly
*/
#ifdef __GNUC__
  ISR(TIMER0_OVF_vect)
#else
#pragma vector = TIM0_OVF_vect
__interrupt void ovfl_timer0(void)
#endif
{
  TC0_WRITE_TCNT0(0x0);
  TIFR |= (1<<TOV0); //Clear TOV0 / clear
  //pending interrupts
  TIMSK |= (1<<TOIE0); //Enable Timer0
}
