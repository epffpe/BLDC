/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Macros for 10 and 16 bit access for the ATtinyX61 family of
 *      microcontrollers.
 *
 * \par Application note:
 *      AVR073: Accessing 10 and 16 bit registers in ATtinyX61
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 * $Name:  $
 * $Revision: 1.2 $
 * $RCSfile: TinyX61_macros.h,v $
 * $Date: 2006/04/25 10:38:06 $  \n
 ******************************************************************************/

#ifndef __TINYX61_MACROS_H__
#define __TINYX61_MACROS_H__

//! Bit mask for the global interrupt flag in SREG.
#define GLOBAL_INTERRUPT_BIT_MASK   0x80

/*
#if defined(__ICCAVR__)
#include <ioavr.h>
#include "stdint.h"
#elif defined(__GNUC__)
#include <avr/io.h>
#include <stdint.h>
#include <avr/interrupt.h>
#else
//Include files for other compilers than IAR and GCC can be inserted here.
#endif
*/
#include "config.h"

#if defined(__ICCAVR__)
//! Save the current interrupt state.
#define SAVE_INTERRUPT()            __save_interrupt();

//! Restore the interrupt state.
#define RESTORE_INTERRUPT(state)    __restore_interrupt(state);

//! Disable global interrupt flag.
#define DISABLE_INTERRUPT()         __disable_interrupt();

#elif defined(__GNUC__)
//! Save the current interrupt state.
#define SAVE_INTERRUPT()            SREG

//! Restore the interrupt state.
#define RESTORE_INTERRUPT(state)    (SREG = (state))

//! Disable global interrupt flag.
#define DISABLE_INTERRUPT()         cli()

#else
//! Save the current interrupt state.
#define SAVE_INTERRUPT()            SREG

//! Restore the interrupt state.
#define RESTORE_INTERRUPT(state)    (SREG = (state))

//! Disable global interrupt flag.
#define DISABLE_INTERRUPT()         (SREG &= (~GLOBAL_INTERRUPT_BIT_MASK))
#endif


/*! \brief Write 16 bit value to TCNT0.
 *
 *  Writes a 16 bit value to TCNT0 (TCNT0L/H).
 *
 *  \param value New 16 bit TCNT0 value.
 */
#define TC0_WRITE_TCNT0(value) \
  { \
    TCNT0H = (uint8_t)((value) >> 8); \
    TCNT0L = (uint8_t)(value); \
  }


/*! \brief Read 16 bit value from TCNT0.
 *
 *  Reads the 16 bit value of TCNT0 (TCNT0L/H).
 *
 *  \param destinationVariable Destination variable.
 */
#define TC0_READ_TCNT0(destinationVariable) \
  { \
    uint8_t tempL; \
    tempL = TCNT0L; \
    (destinationVariable) = ((TCNT0H << 8) | tempL); \
  }


/*! \brief Atomic 16 bit write to TCNT0.
 *
 *  Writes a 16 bit value to TCNT0 (TCNT0L/H) in one atomic operation.
 *
 *  \param value New 16 bit TCNT0 value.
 */
#define TC0_WRITE_TCNT0_INT_SAFE(value) \
  { \
    uint8_t iFlagTemp; \
    iFlagTemp = SAVE_INTERRUPT(); \
    DISABLE_INTERRUPT(); \
    TCNT0H = (uint8_t)((value) >> 8); \
    TCNT0L = (uint8_t)(value); \
    RESTORE_INTERRUPT(iFlagTemp); \
  }


/*! \brief Atomic 16 bit read from TCNT0.
 *
 *  Reads the 16 bit value of TCNT0 (TCNT0L/H) in one atomic operation.
 *
 *  \param destinationVariable Destination variable.
 */
#define TC0_READ_TCNT0_INT_SAFE(destinationVariable) \
  { \
    uint8_t iFlagTemp; \
    uint8_t tempL; \
    iFlagTemp = SAVE_INTERRUPT(); \
    DISABLE_INTERRUPT(); \
    tempL = TCNT0L; \
    (destinationVariable) = ((TCNT0H << 8) | tempL); \
    RESTORE_INTERRUPT(iFlagTemp); \
  }


/*! \brief Write 16 bit value to OCR0A/B.
 *
 *  Writes a 16 bit value to OCR0A/B.
 *
 *  \param value New 16 bit OCR0A/B value.
 */
#define TC0_WRITE_16_BIT_OCR0AB(value) \
  { \
    OCR0B = (uint8_t)((value) >> 8); \
    OCR0A = (uint8_t)(value);\
  }


/*! \brief Read 16 bit value from OCR0A/B.
 *
 *  Reads the 16 bit OCR0A/B value.
 *
 *  \param destinationVariable Destination variable.
 */
#define TC0_READ_16_BIT_OCR0AB(destinationVariable) \
  { \
    uint8_t tempL = OCR0A; \
    (destinationVariable) = ((uint16_t)OCR0B << 8) | tempL; \
  }


/*! \brief Atomic 16 bit read from OCRA/B.
 *
 *  Reads the 16 bit OCR0A/B value in one atomic operation.
 *
 *  \param destinationVariable Destination variable.
 */
#define TC0_READ_16_BIT_OCR0AB_INT_SAFE(destinationVariable) \
  { \
    uint8_t iFlagTemp; \
    iFlagTemp = SAVE_INTERRUPT(); \
    DISABLE_INTERRUPT(); \
    uint8_t tempL = OCR0A; \
    (destinationVariable) = ((uint16_t)OCR0B << 8) | tempL; \
    RESTORE_INTERRUPT(iFlagTemp); \
  }


/*! \brief Write 16 bit value to OCR0A/B.
 *
 *  Writes a 16 bit value to OCR0A/B.
 *
 *  \param value New 16 bit OCR0A/B value.
 */
#define TC0_WRITE_16_BIT_OCR0AB_INT_SAFE(value) \
  { \
    uint8_t iFlagTemp; \
    iFlagTemp = SAVE_INTERRUPT(); \
    DISABLE_INTERRUPT(); \
    OCR0B = (uint8_t)((value) >> 8); \
    OCR0A = (uint8_t)(value);\
    RESTORE_INTERRUPT(iFlagTemp); \
  }


/*! \brief Write 10 bit value to a Timer/Counter1 register.
 *
 *  Writes a 10 bit value to any 10 bit Timer/Counter1 register.
 *
 *  \param destinationRegister Destination register.
 *  \param value Register value.
 */
#define TC1_WRITE_10_BIT_REGISTER(destinationRegister, value) \
  { \
    TC1H = ((value) >> 8); \
    (destinationRegister) = (uint8_t)(value); \
  }


/*! \brief Read 10 bit value from a Timer/Counter1 register.
 *
 *  Reads a 10 bit value from any 10 bit Timer/counter1 register.
 *
 *  \param sourceRegister Source register
 *  \param destinationVariable Destination variable.
 */
#define TC1_READ_10_BIT_REGISTER(sourceRegister, destinationVariable) \
  { \
    uint8_t tempL; \
    tempL = (sourceRegister); \
    (destinationVariable) = ( ((uint16_t)TC1H << 8) | tempL); \
  }


/*! \brief Atomic 10 bit write to a Timer/Counter1 register.
 *
 *  Writes a 10 bit value to any 10 bit Timer/Counter1 register in one atomic.
 *  operation.
 *
 *  \param destinationRegister Destination register.
 *  \param value Register value.
 */
#define TC1_WRITE_10_BIT_REGISTER_INT_SAFE(destinationRegister, value) \
  { \
  uint8_t iFlagTemp; \
  iFlagTemp = SAVE_INTERRUPT(); \
  DISABLE_INTERRUPT(); \
  TC1H = ((value) >> 8); \
  (destinationRegister) = (uint8_t)(value); \
  RESTORE_INTERRUPT(iFlagTemp); \
  }


/*! \brief Atomic 10 bit read from a Timer/Counter1 register.
 *
 *  Reads a 10 bit value from any 10 bit Timer/counter1 register in one atomic
 *  operation.
 *
 *  \param sourceRegister Source register
 *  \param destinationVariable Destination variable
 */
#define TC1_READ_10_BIT_REGISTER_INT_SAFE(sourceRegister, destinationVariable) \
  { \
    uint8_t iFlagTemp; \
    uint8_t tempL; \
    iFlagTemp = SAVE_INTERRUPT(); \
    tempL = (sourceRegister); \
    (destinationVariable) = ( ((uint16_t)TC1H << 8) | tempL); \
    RESTORE_INTERRUPT(iFlagTemp); \
  }


/*! \brief Set same output compare value for all output channels of Timer/counter1.
 *
 *  This macro sets the same output compare value to all three output channels
 *  of Timer/counter1. This does not apply to PWM6 mode, where all channels
 *  controlled by a single compare register.
 *
 *  \param compareValue New output compare value.
 */
#define TC1_SET_ALL_COMPARE_VALUES(compareValue) \
  { \
      uint16_t tempValue = compareValue; \
      TC1H = ((uint8_t)((tempValue) >> 8)); \
      OCR1A = ((uint8_t)tempValue); \
      OCR1B = ((uint8_t)tempValue); \
      OCR1D = ((uint8_t)tempValue); \
  }


#endif
