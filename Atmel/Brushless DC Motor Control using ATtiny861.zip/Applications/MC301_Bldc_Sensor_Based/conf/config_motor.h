//!
//! @file config_motor.h,v
//!
//! Copyright (c) 2007 Atmel.
//!
//! @brief Motor Configuration
//!
//! @version 1.16
//!

//_____  I N C L U D E S ___________________________________________________



#ifndef _CONFIG_MOTOR_H_
#define _CONFIG_MOTOR_H_

/**
 * @brief  This enumeration contains the 6 differents values for the Hall Sensors
 * See design document. In this application, just 3 hall sensor are used
 * Hall Sensor : position 1 to 6
 */
enum {HS_001=1,HS_010=2,HS_011=3,HS_100=4,HS_101=5,HS_110=6};


/**
 * @brief  Define the two states of the motor
 */
  enum {RUN = TRUE, STOP = FALSE};

/**
 * @brief  Define Direction of rotor : CCW and CW
 */
  enum {CCW = TRUE, CW = FALSE};

// Define Type of Pulse Width Modulation
//#define HIGH_AND_LOW_PWM // it doesn't run with AT90PWM3B in centered mode
// AT90PWM3B: for high and low pwm (fast decay mode),
//            please use 1,2 or 4 ramps mode and adjust ADC synchro

// Define type of speed measure and number of samples
//#define AVERAGE_SPEED_MEASURE
#define n_SAMPLE  8

// Define macro for motor control
#define OPEN_LOOP 0
#define SPEED_LOOP 1
#define CURRENT_LOOP 2

// Here you have to define your control coefficients
// Kp for the proportionnal coef
// Ki for the integral coef
// Kd for the derivative coef

// Speed regulation coefficients
#define Kp_speed 8//1 MMT motor//8 MAXON moto
#define Ki_speed 8//10 MMT motor//8 MAXON motor
#define Kd_speed 0

// Current regulation coefficients
#define Kp_cur 1
#define Ki_cur 3
#define Kd_cur 0

// Position regulation coefficients
#define Kp_pos 9 //8
#define Ki_pos 3 //1
#define Kd_pos 20 //5

// All PID coef are multiplied by 2^Kmul
// For exemple : kp = 1 => Kp = 1 * 2^K_scal = 1 * 2^4 = 16
// To get the right result you have to divide the number by 2^K_scal
// So execute a K_scal right shift
#define K_speed_scal 4 // 4 MMT motor//5 MAXON motor
#define K_cur_scal 4
#define K_pos_scal 5

// Speed measurement
// K_SPEED = (60 * 255)/(n * t_timer0 * speed_max(rpm))
// with n : number of pairs of poles.
// and t_timer0 : 16us
#define K_SPEED 34152 // max speed : 7000 (MC100 motor)
//#define K_SPEED 11250 // max speed : 17000 (MMT 35-1LS motor)
// if you want to calculate the absolute speed
//   absolute_speed = alpha * measured_speed
//   with alpha = 60 / (n * K_SPEED * t_timer0)

#endif

/* IMAX for DAC is calculated on that way :
   Rshunt = 0.1Ohm
   Vref = 2.56V
   DAC is left adjust so it is like a 8 bit DAC
   IMAX = imax(amp) * 256 * 0.1 / 2.56
   IMAX = imax * 10 */
#define IMAX (6 * 10) /* 6 amps */
