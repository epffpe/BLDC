//! @file $RCSfile: config.h,v $
//!
//! Copyright (c) 2006 Atmel.
//!
//! Please read file license.txt for copyright notice.
//!
//! This file contains the system configuration definition
//!
//! @version $Revision: 585 $ $Name:  $ $Id: config.h 585 2007-12-11 16:43:17Z rletendu $
//!
//! @todo
//! @bug

#ifndef _CONFIG_H_
#define _CONFIG_H_

//! @defgroup global_config Application configuration
//! @{
#include "compiler.h"             // Compiler definitions
#ifdef __GNUC__
   #include <avr/io.h>                    // Use AVR-GCC library
#elif __ICCAVR__
   #include <ioavr.h>                     // Use IAR-AVR library
#else
   #error Current COMPILER not supported
#endif


#ifdef  __GNUC__
   #include <avr/power.h>
#endif

//_____ I N C L U D E S ____________________________________________________

#include "compiler.h" //!< Compiler definitions
#include "config_motor.h"

//#define MOTOR_CONTROL_CENTER

//! CPU core frequency in kHz
#define FOSC 8000

// Sample TWI transmission commands
#define TWI_CMD_MASTER_WRITE 0x10
#define TWI_CMD_MASTER_READ  0x20
#define TWI_CMD_MASTER_WRITE_ALOT 0x30

#define TWI_SLAVE
#define TWI_BAUDRATE      80	 // in kbit
#define TWI_SLAVE_ADDRESS 0x10   // TWI Slave Address = 0x10

#define BOARD_ID 3 /* 0:unknown, 1 : MC100, 2 : MC200, 3 : MC301, 4 : MC310 */
#define SOFT_ID  1 /* 0:unknown, 1:bldc sensor, 2:bldc sinus, 3:bldc sensorless */
#define REV_ID   1

#define NO_ANSWER         0x99

//Direction flag for forward.
#define DIRECTION_FORWARD   0

//Direction flag for reverse.
#define DIRECTION_REVERSE   1

//State flag for stop.
#define STATE_STOP   0

//State flag for run.
#define STATE_RUN   1

#define MOTOR_CONTROL_CENTER  0
#define POTENTIOMETER         1

//Flag struct. Used to place several flags in a register in low I/O space for
//fast bit access.
typedef struct {
  U8 current : 8;
  U16 speed : 16;
  U8 state : 1;
  U8 direction : 1;
} motorControlFlags_t;
// -------- END Generic Configuration -------------------------------------


//! @}


//! Clear_prescaler.
//!
//! This function reset the internal CPU core clock prescaler
//!
//!
//! @param none
//!
//! @return none.
//!
#ifdef  __GNUC__
   #define Clear_prescaler()                       (clock_prescale_set(0))
#else
   #define Clear_prescaler()                       (Set_cpu_prescaler(0))
#endif

//! Set_prescaler.
//!
//! This function configure the internal CPU core clock prescaler value
//!
//!
//! @param x: prescaler new value
//!
//! @return none.
//!
#ifdef  __GNUC__
   #define Set_cpu_prescaler(x)                        (clock_prescale_set(x))
#else
   extern void Set_cpu_prescaler(U8 x);
#endif
   
#endif // _CONFIG_H_

