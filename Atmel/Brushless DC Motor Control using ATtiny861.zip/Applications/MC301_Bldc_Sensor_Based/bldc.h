
#ifndef BLDC_H
#define BLDC_H

#include "config.h"

//Driver stage pin mapping.
#define UL    PB0
#define UH    PB1
#define VL    PB2
#define VH    PB3
#define WL    PB4
#define WH    PB5

//Forward driving patterns.
#define CS1_FWD   ((1 << VL) | (1 << WH))
#define CS2_FWD   ((1 << VL) | (1 << UH))
#define CS3_FWD   ((1 << WL) | (1 << UH))
#define CS4_FWD   ((1 << WL) | (1 << VH))
#define CS5_FWD   ((1 << UL) | (1 << VH))
#define CS6_FWD   ((1 << UL) | (1 << WH))

//Reverse driving patterns.
#define CS1_REV   ((1 << WL) | (1 << VH))
#define CS2_REV   ((1 << WL) | (1 << UH))
#define CS3_REV   ((1 << VL) | (1 << UH))
#define CS4_REV   ((1 << VL) | (1 << WH))
#define CS5_REV   ((1 << UL) | (1 << WH))
#define CS6_REV   ((1 << UL) | (1 << VH))

//Table of output patterns for forward driving indexed on hall sensor value.
#ifdef __ICCAVR__
code U8
#elif __GNUC__
U8
#endif
commTableForward[8] = {
  0x00,     //Hall == 0, Illegal hall sensor state, disable drivers.
  CS6_FWD,  //Hall == 1
  CS2_FWD,  //Hall == 2
  CS1_FWD,  //Hall == 3
  CS4_FWD,  //Hall == 4
  CS5_FWD,  //Hall == 5
  CS3_FWD,  //Hall == 6
  0x00      //Hall == 7, Illegal hall sensor state, disable drivers.
};

//Table of output patterns for reverse driving indexed on hall sensor value.
#ifdef __ICCAVR__
code U8
#elif __GNUC__
U8
#endif
commTableReverse[8] = {
   0x00,     //Hall == 0, Illegal hall sensor state, disable drivers.
  CS2_REV,  //Hall == 1
  CS6_REV,  //Hall == 2
  CS1_REV,  //Hall == 3
  CS4_REV,  //Hall == 4
  CS3_REV,  //Hall == 5
  CS5_REV,  //Hall == 6
  0x00      //Hall == 7, Illegal hall sensor state, disable drivers.,
};

//Top value for the PWM timer.
#define PWM_TOP_VALUE     0x3ff

//ADC MUX setting to select PA7.
#define ADMUX_PA7   ((1 << MUX2) | (1 << MUX1))
#define ADMUX_PA1   ((1 << MUX0))
#define ADMUX_PA2   ((2 << MUX0))

//ADC prescaler setting.
#define ADC_PRESCALER (1 << ADPS2)

//Trigger source selection to set ADC in free-running mode.
#define ADC_TS_FREERUNNING  ((0 << ADTS2) | (0 << ADTS1) | (0 << ADTS0))


//Maximum ADC reading.
#define ADC_MAX 0x1EB     // Based on measurement
#define ADC_TWI 0x3FF     // When TWI connected to ADC

//Address of GPIO register 0. (Used for fast access to flag variables.)
#define GPIOR0_ADDR         0x2a

// Speed measurement
// K_SPEED = (60 * 255)/(n * t_timer0 * speed_max(rpm))
// with n : number of pairs of poles.
// and t_timer0 : 16us
#define K_SPEED 34152 // max speed : 7000 (MC100 motor)
//#define K_SPEED 11250 // max speed : 17000 (MMT 35-1LS motor)
// if you want to calculate the absolute speed
//   absolute_speed = alpha * measured_speed
//   with alpha = 60 / (n * K_SPEED * t_timer0)


//Function prototypes.
extern void Commutate(void);
extern void PLLInit(void);
extern void PWMInit(void);
extern void HallSensorInit(void);
extern void ADCInit(void);
extern void Timer0Init(void);
extern void PortsInit(void);
extern void MotorSetDutyCycle(U16 duty);
extern void SpeedMeasurement(void);


#endif
