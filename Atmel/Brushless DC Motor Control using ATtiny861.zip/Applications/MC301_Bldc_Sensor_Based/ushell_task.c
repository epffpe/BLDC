//!
//! @file ushell_task.c,v
//!
//! Copyright (c) 2006 Atmel.
//!
//! @brief This file manages the �shell task for communication.
//!
//! @version 1.2
//!

//_____  I N C L U D E S ___________________________________________________

#include "config.h"
#include "ushell_task.h"
#include "ascii.h"
#include "USI_TWI_Slave.h"


U16 debug_get_value1(void);
U16 debug_get_value2(void);

extern volatile motorControlFlags_t mcFastFlags;
extern volatile U16 SpeedMeasure;

//_____ M A C R O S ________________________________________________________

//_____ D E F I N I T I O N S ______________________________________________
//void convert_param1(void);
//void print_hex16(U16 value);
extern void MotorSetDutyCycle(U16 duty);

//_____ D E C L A R A T I O N S ____________________________________________

extern U16 speed;
extern U16 current;
extern U8 direction;
volatile Bool ushell_active = FALSE;
volatile U8  debug8;

//! @brief This function initializes the hardware/software ressources required for ushell task.
//!
//!
//! @param none
//!
//! @return none
//!
//!/
void ushell_task_init(void)
{
#ifdef __GNUC__
// 	fdevopen((int (*)(char, FILE*))(USI_TWI_Transmit_Byte),(int (*)(FILE*))USI_TWI_Receive_Byte); //for printf redirection
#endif
}





//! @brief Entry point of the explorer task management
//!
//! This function links perform ushell task decoding to access file system functions.
//!
//!
//! @param none
//!
//! @return none
void ushell_task(void)
{
   if (is_data_received)    //Something new of  the UART ?
   {
      is_data_received=FALSE;
      switch (data_received)
      {
         case CMD_RUN:
            mcFastFlags.state = STATE_RUN;
            mcFastFlags.speed = (U16)(LSB(speed)<<2);
           break;
            
         case CMD_STOP:
            mcFastFlags.state = STATE_STOP;
            break;
            
         case CMD_FORWARD:
            mcFastFlags.direction = DIRECTION_FORWARD;
            break;
            
         case CMD_BACKWARD:
            mcFastFlags.direction = DIRECTION_REVERSE;
            break;
            
         case CMD_SET_SPEED:
           MSB(speed) = USI_TWI_Receive_Byte();
           LSB(speed) = USI_TWI_Receive_Byte();
           mcFastFlags.speed = (U16)(LSB(speed)<<2);
            break;
            
         case CMD_GET_ID:
            USI_TWI_Transmit_Byte(BOARD_ID);
            USI_TWI_Transmit_Byte(SOFT_ID);
            USI_TWI_Transmit_Byte(REV_ID);
            break;
            
         case CMD_GET_STATUS:
//              if(SpeedMeasure!=0)
//                current=12;
//              USI_TWI_Transmit_Byte(MSB(SpeedMeasure));
//              USI_TWI_Transmit_Byte(LSB(SpeedMeasure));
              USI_TWI_Transmit_Byte(MSB(speed));
              USI_TWI_Transmit_Byte(LSB(speed));
              USI_TWI_Transmit_Byte(MSB(current));
              USI_TWI_Transmit_Byte(LSB(current));

            ushell_active = TRUE;
            break;
         default:    //Unknown command
            break;
      }
      data_received=CMD_NONE;
   }
}

