//!
//! @file $RCSfile: ushell_task.h,v $
//!
//! Copyright (c) 2006 Atmel.
//!
//! @brief This file contains the ushell_task.c function declarations
//!
//! @version $Revision: 1.2 $
//!

#ifndef _USHELL_TASK_H_
#define _USHELL_TASK_H_

//_____ I N C L U D E S ____________________________________________________

#include "config.h"

//_____ M A C R O S ________________________________________________________


// Commands shell
#define CMD_NONE           0x00
#define CMD_RUN            0x01
#define CMD_STOP           0x02
#define CMD_FORWARD        0x03
#define CMD_BACKWARD       0x04
#define CMD_SET_SPEED      0x05
#define CMD_SET_JP         0x06
#define CMD_GET_STATUS     0x07
#define CMD_GET_ID         0x08
#define CMD_WR_REGPARAM    0x09
#define CMD_RD_REGPARAM    0x0A


//_____ D E C L A R A T I O N S ____________________________________________
extern volatile Bool ushell_active;
extern Bool is_data_to_send;
extern Bool is_data_received;
extern unsigned char data_to_send;
extern unsigned char data_received;


void   build_cmd(void);
void   parse_cmd(void);
void   ushell_task_init(void);
void   ushell_task(void);

#endif /* _USHELL_TASK_H_ */
