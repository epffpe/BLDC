//******************************************************************************
//!
//! @file $Id: mc_drv.h 2023 2008-09-10 16:19:44Z raubree $
//!
//! Copyright (c) 2007 Atmel.
//!
//! @brief Low Level Functions
//!
//!
//! @todo
//! @bug
//******************************************************************************


#ifndef _MC_DRV_H_
#define _MC_DRV_H_

#include "config.h"

  #define Disable_over_current() \
   Psc_config_input_1(PSC_OVERLAP_ENABLE,\
                      PSC_USE_COMPARATOR,\
                      PSC_USE_HIGH_LEVEL,\
                      PSC_INPUT_FILTER_ENABLE,\
                      PSC_SYNCHRONOUS_OUTPUT_CONTROL,\
                      PSC_INPUT_NO_ACTION);

  #define Enable_over_current() \
   Psc_config_input_1(PSC_OVERLAP_ENABLE,\
                      PSC_USE_COMPARATOR,\
                      PSC_USE_HIGH_LEVEL,\
                      PSC_INPUT_FILTER_ENABLE,\
                      PSC_SYNCHRONOUS_OUTPUT_CONTROL,\
                      PSC_INPUT_HALT);



  // Comparator interruption
  #define HALL_A() (PCINT1_vect)
  #define HALL_B() (PCINT0_vect)


  #define HALL_SENSOR_VALUE()        \
    (Motor_Position)(\
    ( (PINC & (1<<PINC3)) >> PINC3 ) \
  | ( (PINB & (1<<PINB3)) >> 2 )     \
  | ( (PINB & (1<<PINB4)) >> 2 ))

  #define Clear_Port_Q5() (PORTB &= ( ~(1<<PORTB0)))
  #define Clear_Port_Q3() (PORTC &= ( ~(1<<PORTC0)))
  #define Clear_Port_Q1() (PORTD &= ( ~(1<<PORTD0)))
  #define Clear_Port_Q6() (PORTB &= ( ~(1<<PORTB1)))
  #define Clear_Port_Q4() (PORTB &= ( ~(1<<PORTB6)))
  #define Clear_Port_Q2() (PORTB &= ( ~(1<<PORTB7)))
  #define Set_Port_Q2()   (PORTB |=   (1<<PORTB1))
  #define Set_Port_Q4()   (PORTB |=   (1<<PORTB6))
  #define Set_Port_Q6()   (PORTB |=   (1<<PORTB7))

  // Six step commutation
  #define Set_none()                \
    POC = (0<<POEN0A)|(0<<POEN0B)|\
          (0<<POEN1A)|(0<<POEN1B)|\
          (0<<POEN2A)|(0<<POEN2B);\
    Clear_Port_Q2();                \
    Clear_Port_Q4();                \
    Clear_Port_Q6();                \
    Clear_Port_Q1();                \
    Clear_Port_Q3();                \
    Clear_Port_Q5();

#if (CURRENT_DECAY == SLOW_DECAY_SYNCHRONOUS)
  #define Set_Q5Q4()                \
    PORTB &= ( ~((1<<PORTB1)|(1<<PORTB7)));\
    POC = (0<<POEN0A)|(0<<POEN0B)|\
          (0<<POEN1A)|(0<<POEN1B)|\
          (1<<POEN2A)|(1<<POEN2B);\
    PORTB |=   (1<<PORTB6);

  #define Set_Q5Q2()                \
    PORTB &= ( ~((1<<PORTB1)|(1<<PORTB6)));\
    POC = (0<<POEN0A)|(0<<POEN0B)|\
          (0<<POEN1A)|(0<<POEN1B)|\
          (1<<POEN2A)|(1<<POEN2B);\
    PORTB |=   (1<<PORTB7);

  #define Set_Q3Q6()                \
    PORTB &= ( ~((1<<PORTB6)|(1<<PORTB7)));\
    POC = (0<<POEN0A)|(0<<POEN0B)|\
          (1<<POEN1A)|(1<<POEN1B)|\
          (0<<POEN2A)|(0<<POEN2B);\
    PORTB |=   (1<<PORTB1);

  #define Set_Q3Q2()                \
    PORTB &= ( ~((1<<PORTB1)|(1<<PORTB6)));\
    POC = (0<<POEN0A)|(0<<POEN0B)|\
          (1<<POEN1A)|(1<<POEN1B)|\
          (0<<POEN2A)|(0<<POEN2B);\
    PORTB |=   (1<<PORTB7);

  #define Set_Q1Q6()                \
    PORTB &= ( ~((1<<PORTB6)|(1<<PORTB7)));\
    POC = (1<<POEN0A)|(1<<POEN0B)|\
          (0<<POEN1A)|(0<<POEN1B)|\
          (0<<POEN2A)|(0<<POEN2B);\
    PORTB |=   (1<<PORTB1);

  #define Set_Q1Q4()                \
    PORTB &= ( ~((1<<PORTB1)|(1<<PORTB7)));\
    POC = (1<<POEN0A)|(1<<POEN0B)|\
          (0<<POEN1A)|(0<<POEN1B)|\
          (0<<POEN2A)|(0<<POEN2B);\
    PORTB |=   (1<<PORTB6);
  // *** end SLOW_DECAY_SYNCHRONOUS
#else

#if (CURRENT_DECAY == FAST_DECAY_SYNCHRONOUS)
  #define Set_Q5Q4()                \
    POC=0;\
    PCTL =  (PCTL&~((1<<PSWAP2)|(1<<PSWAP1)|(1<<PSWAP0)))\
                 | ((0<<PSWAP2)|(1<<PSWAP1)|(0<<PSWAP0));\
    POC = (0<<POEN0A)|(0<<POEN0B)|\
          (1<<POEN1A)|(1<<POEN1B)|\
          (1<<POEN2A)|(1<<POEN2B);

  #define Set_Q5Q2()                \
    POC=0;\
    PCTL =  (PCTL&~((1<<PSWAP2)|(1<<PSWAP1)|(1<<PSWAP0)))\
                 | ((0<<PSWAP2)|(0<<PSWAP1)|(1<<PSWAP0));\
    POC = (1<<POEN0A)|(1<<POEN0B)|\
          (0<<POEN1A)|(0<<POEN1B)|\
          (1<<POEN2A)|(1<<POEN2B);

  #define Set_Q3Q6()                \
    POC=0;\
    PCTL =  (PCTL&~((1<<PSWAP2)|(1<<PSWAP1)|(1<<PSWAP0)))\
                 | ((1<<PSWAP2)|(0<<PSWAP1)|(0<<PSWAP0));\
    POC = (0<<POEN0A)|(0<<POEN0B)|\
          (1<<POEN1A)|(1<<POEN1B)|\
          (1<<POEN2A)|(1<<POEN2B);

  #define Set_Q3Q2()                \
    POC=0;\
    PCTL =  (PCTL&~((1<<PSWAP2)|(1<<PSWAP1)|(1<<PSWAP0)))\
                 | ((0<<PSWAP2)|(0<<PSWAP1)|(1<<PSWAP0));\
    POC = (1<<POEN0A)|(1<<POEN0B)|\
          (1<<POEN1A)|(1<<POEN1B)|\
          (0<<POEN2A)|(0<<POEN2B);

  #define Set_Q1Q6()                \
    POC=0;\
    PCTL =  (PCTL&~((1<<PSWAP2)|(1<<PSWAP1)|(1<<PSWAP0)))\
                 | ((1<<PSWAP2)|(0<<PSWAP1)|(0<<PSWAP0));\
    POC = (1<<POEN0A)|(1<<POEN0B)|\
          (0<<POEN1A)|(0<<POEN1B)|\
          (1<<POEN2A)|(1<<POEN2B);

  #define Set_Q1Q4()                \
    POC=0;\
    PCTL =  (PCTL&~((1<<PSWAP2)|(1<<PSWAP1)|(1<<PSWAP0)))\
                 | ((0<<PSWAP2)|(1<<PSWAP1)|(0<<PSWAP0));\
    POC = (1<<POEN0A)|(1<<POEN0B)|\
          (1<<POEN1A)|(1<<POEN1B)|\
          (0<<POEN2A)|(0<<POEN2B);\
  // *** end FAST_DECAY_SYNCHRONOUS

#else 

  // *** then SLOW_DECAY or FAST_DECAY
  #define Set_Q5Q4()                \
    POC = (0<<POEN0A)|(0<<POEN0B)|\
          (0<<POEN1A)|(1<<POEN1B)|\
          (1<<POEN2A)|(0<<POEN2B);

  #define Set_Q5Q2()                \
    POC = (0<<POEN0A)|(1<<POEN0B)|\
          (0<<POEN1A)|(0<<POEN1B)|\
          (1<<POEN2A)|(0<<POEN2B);

  #define Set_Q3Q6()                \
    POC = (0<<POEN0A)|(0<<POEN0B)|\
          (1<<POEN1A)|(0<<POEN1B)|\
          (0<<POEN2A)|(1<<POEN2B);

  #define Set_Q3Q2()                \
    POC = (0<<POEN0A)|(1<<POEN0B)|\
          (1<<POEN1A)|(0<<POEN1B)|\
          (0<<POEN2A)|(0<<POEN2B);

  #define Set_Q1Q6()                \
    POC = (1<<POEN0A)|(0<<POEN0B)|\
          (0<<POEN1A)|(0<<POEN1B)|\
          (0<<POEN2A)|(1<<POEN2B);

  #define Set_Q1Q4()                \
    POC = (1<<POEN0A)|(0<<POEN0B)|\
          (0<<POEN1A)|(1<<POEN1B)|\
          (0<<POEN2A)|(0<<POEN2B);
#endif
#endif

/* different comparator configurations for demagnetization mask */
  #define Force_CMP0_high()             \
    PORTD |= (1<<PORTD7);   /* PD7 = 1*/\
    PORTB &= ~(1<<PORTB2);  /* PB2 = 0*/\
    DDRD |= (1<<DDD7);                  \
    DDRB |= (1<<DDB2);

  #define Force_CMP0_low()              \
    PORTD &= ~(1<<PORTD7);  /* PD7 = 0*/ \
    PORTB |= (1<<PORTB2);   /* PB2 = 1*/\
    DDRD |= (1<<DDD7);                 \
    DDRB |= (1<<DDB2);

  #define Release_CMP0()              \
    DDRD &= ~(1<<DDD7);                 \
    DDRB &= ~(1<<DDB2);

  #define Force_CMP1_high()             \
    PORTC |= (1<<PORTC6);   /* PC6 = 1*/\
    PORTB &= ~(1<<PORTB5);  /* PB5 = 0*/\
    DDRC |= (1<<DDC6);                  \
    DDRB |= (1<<DDB5);

  #define Force_CMP1_low()              \
    PORTC &= ~(1<<PORTC6);  /* PC6 = 0*/ \
    PORTB |= (1<<PORTB5);   /* PB5 = 1*/\
    DDRC |= (1<<DDC6);                 \
    DDRB |= (1<<DDB5);

  #define Release_CMP1()              \
    DDRC &= ~(1<<DDC6);                 \
    DDRB &= ~(1<<DDB5);

  #define Force_CMP2_high()             \
    PORTD |= (1<<PORTD5);   /* PD5 = 1*/\
    PORTD &= ~(1<<PORTD6);  /* PD6 = 0*/\
    DDRD |= ((1<<DDD6)|(1<<DDD5));

  #define Force_CMP2_low()              \
    PORTD &= ~(1<<PORTD5);  /* PD5 = 0*/ \
    PORTD |= (1<<PORTD6);   /* PD6 = 1*/\
    DDRD |= ((1<<DDD6)|(1<<DDD5));

  #define Release_CMP2()              \
    DDRD &= ~((1<<DDD6)|(1<<DDD5));

  #define Enable_IT_comparator2_1_0() \
    ACSR |= (1<<AC2IF)|(1<<AC1IF)|(1<<AC0IF);  \
    AC0CON |= (1<<AC0IE); \
    AC1CON |= (1<<AC1IE); \
    AC2CON |= (1<<AC2IE);

  #define Enable_IT_comparator0() \
    ACSR |= (1<<AC0IF);           \
    AC0CON |= (1<<AC0IE);

  #define Enable_IT_comparator1() \
    ACSR |= (1<<AC1IF);           \
    AC1CON |= (1<<AC1IE);

  #define Enable_IT_comparator2() \
    ACSR |= (1<<AC2IF);           \
    AC2CON |= (1<<AC2IE);

  #define Disable_IT_comparator2_1_0() \
    AC0CON &= ~((1<<AC0IE)); \
    AC1CON &= ~((1<<AC1IE)); \
    AC2CON &= ~((1<<AC2IE));

  #define Disable_IT_comparator0() \
    AC0CON &= ~(1<<AC0IE);

  #define Disable_IT_comparator1() \
    AC1CON &= ~(1<<AC1IE);

  #define Disable_IT_comparator2() \
    AC2CON &= ~(1<<AC2IE);

  #define STATE_CMP0  0
  #define STATE_CMP1  1
  #define STATE_CMP2  2
  #define STATE_CW100 3
  #define STATE_CW110 4
  #define STATE_CW010 5
  #define STATE_CW011 6
  #define STATE_CW001 7
  #define STATE_CW101 8

  // ADC scheduler definitions
  #define CONV_INIT     0
  #define CONV_POT      1
  #define CONV_CURRENT  2

  #define FREE  0
  #define BUSY  1
  /**************************/
  /* prototypes declaration */
  /**************************/

  // Hardware initialization
  void mc_init_HW(void);
  void PSC_Init (void);
  void start_running_phase(void);

  // Phases commutation functions
  Motor_Position mc_get_hall(void);
  void mc_duty_cycle(U8 level);
  void mc_switch_commutation(Motor_Position position);

  // Sampling time configuration
  void mc_init_timer1(void);

  // Estimation speed
  void mc_init_timer0(void);
  void mc_estimation_speed(void);

  // ADC use for current measure and potentiometer...
  void mc_ADC_Scheduler(void);
  U8 mc_Get_Current(void);
  U8 mc_Get_Potentiometer(void);

  // Over Current Detection
  void mc_disable_during_inrush(void);
  void mc_inrush_task(void); /* manage the inrush current */

#endif
