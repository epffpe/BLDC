//******************************************************************************
//!
//! @file $Id: mc_drv.c 2046 2008-09-12 13:50:27Z raubree $
//!
//! Copyright (c) 2008 Atmel.
//!
//! @brief Driver level : Init, PWM ...
//!
//! @todo
//! @bug
//******************************************************************************

/* Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


//_____  I N C L U D E S ___________________________________________________

#include "config.h"

#include "mc_drv.h"
#include "mc_interface.h"
#include "mc_control.h"

#include "psc\psc_drv.h"
#include "adc\adc_drv.h"
#include "dac\dac_drv.h"
#include "pll\pll_drv.h"
#include "comparator\comparator_drv.h"

#define PSWAP0 2
#define PSWAP1 3
#define PSWAP2 4

Bool overcurrent = FALSE;

U8 count = 1;     // variable "count" is use to calculate the "average" speed on 'n' samples
U16 average = 0;
static volatile U8 timer0_ext = 0; // variable "timer0_ext" is use to simulate a 16 bits timer with 8 bits timer

static Bool inrush_mask_flag = FALSE;
static U16 inrush_delay = 0;

static U16 stored_time = 0;

static U32 top_average = 200;

static U8 motor_step;

volatile Bool g_tick = FALSE;             //!< Use for control the sampling period value

Bool current_EOC = FALSE; //End Of Conversion Flag

static char State = CONV_INIT; // State of the ADC scheduler
static char ADC_State = FREE;  // ADC State : running = BUSY not running = FREE

/******************************************************************************/
/******************************************************************************/
/*        Hardware Initialization                                             */
/******************************************************************************/
/******************************************************************************/


//! @brief mc_init_HW : Hardware Initialization
//! @post initialization of hardware
void mc_init_HW(void)
{
  // Output Pin configuration (used by PSC outputs)
  // PD0 => UH     PB7 => UL
  // PC0 => VH     PB6 => VL
  // PB0 => WH     PB1 => WL

  // Warning Output Low for MOSFET Drivers
  PORTB &= ~(1<<PORTB7 | 1<<PORTB6 | 1<<PORTB1 | 1<<PORTB0);
  PORTC &= ~(1<<PORTC0);
  PORTD &= ~(1<<PORTD0);

/* to removed */
  PORTB |= (1<<PORTB4)|(1<<PORTB3); /* activate PB4 and PB3 pull up for sensorless debug */
  PORTC |= (1<<PORTC3); /* activate PC3 pull up for sensorless debug */

/* pull up for external comparators : to remove when internal comp are used */ 
#ifdef USE_INTERNAL_COMPARATORS
#else
  PORTD |= (1<<PORTD7)|(1<<PORTD5);
  PORTC |= (1<<PORTC6);
#endif

  // PORT B :
  DDRB = (1<<DDB7)|(1<<DDB6)|(1<<DDB1)|(1<<DDB0);
  // PORT C :
  DDRC = (1<<DDC0);
  // PORT D :
  DDRD = (1<<DDD0);
  // PORT E : /* to be removed */
  DDRE |= (1<<DDE2)|(1<<DDE1);

  Init_PC7(); /* PC7 is used to display the overcurrent */

  // Disable Digital Input for amplifier1
  DIDR1 = (1<<ADC9D)|(1<<ADC8D);

  // Disable Digital Input for comparators 0, 1 & 2  : to remove when external comp are used 
#ifdef USE_INTERNAL_COMPARATORS
  DIDR0 = (1<<ADC6D)|(1<<ADC5D)|(1<<ADC3D)|(1<<ADC2D);
  DIDR1 = (1<<ADC10D)|(1<<ACMP0D);
#endif

  // Select the Vref Source
//  init_vref_source ();

//  init_adc();
  Adc_config();
  Amp1_config();
  
  // Be careful : initialize DAC and Over_Current before PWM.
  // DAC is used for oevr current level
  Dac_config();
  /* set the overcurrent level */
  Dac_set_8_bits(IMAX);
    
  mc_init_timer0();
  mc_init_timer1();

  Comp_0_config();
  Comp_1_config();
  Comp_2_config();
  
  // Use PCINT14 to detect change on H2 sensor
  PCMSK0 = (1<<PCINT4)|(1<<PCINT3);
  PCMSK1 = (1<<PCINT11);
  PCICR = (1<<PCIE1)|(1<<PCIE0);

//  Start_pll_32_mega(); // Start the PLL and use the 32 MHz PLL output
  Start_pll_64_mega(); // Start the PLL and use the 64 MHz PLL output
  Wait_pll_ready();


  // => PSCx_Init(Period_Half, Dutyx0_Half, Synchro, Dutyx1_Half)
  PSC_Init();

}




//! @brief PSC Init : Initialize the PSC according to the settings in config.h
void PSC_Init (void)
{
   Psc_set_module_A(A_SA_VAL,A_RA_VAL,A_SB_VAL);
   Psc_set_module_B(B_SA_VAL,B_RA_VAL,B_SB_VAL);
   Psc_set_module_C(C_SA_VAL,C_RA_VAL,C_SB_VAL);
   Psc_set_register_RB(RB_VAL);

   Psc_config();

   Psc_config_input_0(PSC_OVERLAP_ENABLE,\
                      PSC_USE_PIN,\
                      PSC_USE_LOW_LEVEL,\
                      PSC_INPUT_FILTER_ENABLE,\
                      PSC_SYNCHRONOUS_OUTPUT_CONTROL,\
                      PSC_INPUT_NO_ACTION);

   Psc_config_input_1(PSC_OVERLAP_ENABLE,\
                      PSC_USE_COMPARATOR,\
                      PSC_USE_HIGH_LEVEL,\
                      PSC_INPUT_FILTER_ENABLE,\
                      PSC_SYNCHRONOUS_OUTPUT_CONTROL,\
                      PSC_INPUT_NO_ACTION);

   Psc_config_input_2(PSC_OVERLAP_ENABLE,\
                      PSC_USE_PIN,\
                      PSC_USE_LOW_LEVEL,\
                      PSC_INPUT_FILTER_ENABLE,\
                      PSC_SYNCHRONOUS_OUTPUT_CONTROL,\
                      PSC_INPUT_NO_ACTION);

   PIFR = (1<<PEV2)|(1<<PEV1)|(1<<PEV0)|(1<<PEOP);
   PIM = (1<<PEVE1);

   Psc_run();
}

/***************************************************************************/
/***************************************************************************/
/*     All functions for motor's phases commutation                        */
/***************************************************************************/
/***************************************************************************/

/**
* @brief Get the value of hall sensors (1 to 6)
* @param return an unsigned char
*  value of hall sensor
* @pre configuration of port PB and PD
* @post new value of position
*/
Motor_Position mc_get_hall(void)
{
  return HALL_SENSOR_VALUE();
}

/**
 * @brief External interruption
 *                 Sensor (A) mode toggle
 * @pre configuration of external interruption (initialization)
 * @post New value in Hall variable
 */
#ifdef __GNUC__
  ISR(HALL_A())
#else
#pragma vector = HALL_A()
__interrupt void mc_hall_a(void)
#endif
{
//  if (ramp_up == TRUE) mc_switch_commutation(HALL_SENSOR_VALUE());
//  mc_switch_commutation(HALL_SENSOR_VALUE());

  //estimation speed on rising edge of Hall_A
  if (PINC&(1<<PORTC3))
  {
    mc_estimation_speed();
  }

}

/**
 * @brief External interruption
 *                 Hall Sensor (B) mode toggle
 * @pre configuration of external interruption (initialization)
 * @post New value in Hall variable
 */
#ifdef __GNUC__
  ISR(HALL_B())
#else
#pragma vector = HALL_B()
__interrupt void mc_hall_b(void)
#endif
{
//  if (ramp_up == TRUE) mc_switch_commutation(HALL_SENSOR_VALUE());
//  mc_switch_commutation(HALL_SENSOR_VALUE());
}



/**
* @brief Set the duty cycle values in the PSC according to the value calculate by the regulation loop
*/
void mc_duty_cycle(U8 level)
{
   U8 duty;
   duty = level;

#if ((CURRENT_DECAY == SLOW_DECAY_SYNCHRONOUS)||(CURRENT_DECAY == FAST_DECAY_SYNCHRONOUS))
   U8 dutydt;   /* duty with dead time */
   if (duty >= DEADTIME) dutydt = duty - DEADTIME;
#endif
   
   Psc_lock();

  // Duty = 0   => Duty Cycle   0%
  // Duty = 255 => Duty Cycle 100%
 
#if (CURRENT_DECAY == FAST_DECAY)
   Psc_set_module_A(duty,A_RA_VAL,duty);
   Psc_set_module_B(duty,B_RA_VAL,duty);
   Psc_set_module_C(duty,C_RA_VAL,duty);
#else
#if ((CURRENT_DECAY == SLOW_DECAY_SYNCHRONOUS)||(CURRENT_DECAY == FAST_DECAY_SYNCHRONOUS))
   Psc_set_module_A(duty,A_RA_VAL,dutydt);
   Psc_set_module_B(duty,B_RA_VAL,dutydt);
   Psc_set_module_C(duty,C_RA_VAL,dutydt);
#else
   Psc_set_module_A(duty,A_RA_VAL,0);
   Psc_set_module_B(duty,B_RA_VAL,0);
   Psc_set_module_C(duty,C_RA_VAL,0);
#endif
#endif
   
   Psc_unlock();
}

/**
* @brief Set the Switching Commutation value on outputs
*
* @param position (1 to 6) and direction (FORWARD or BACKWARD)
*/
void mc_switch_commutation(Motor_Position position)
{
  // get the motor direction to commute the right switches.
  char direction = mci_get_motor_direction();

  // Switches are commuted only if the user start the motor
  if (mci_motor_is_running())
  {
    switch(position)
    {
    // cases according to rotor position
      case MS_001:  {Set_Q1Q6();motor_step=MS_001;}
                    break;

      case MS_101:  {Set_Q1Q4();motor_step=MS_101;}
                    break;

      case MS_100:  {Set_Q5Q4();motor_step=MS_100;}
                    break;

      case MS_110:  {Set_Q5Q2();motor_step=MS_110;}
                    break;

      case MS_010:  {Set_Q3Q2();motor_step=MS_010;}
                    break;

      case MS_011:  {Set_Q3Q6();motor_step=MS_011;}
                    break;
      default : break;
    }
  }
  else
  {
    Set_none(); // all switches are switched OFF
  }
}

/******************************************************************************/
/******************************************************************************/
/*    TIMER 1 :  generate the g_tick                                          */
/******************************************************************************/
/******************************************************************************/

/**
* @brief timer 1 Configuration
*/
void mc_init_timer1(void)
{
  TCCR1A = 0; //Normal port operation + Mode CTC
  TCCR1B = 1<<CS11 | 1<<CS10 ; // Mode CTC + prescaler 64 => T timer1 = 4�S
  TCCR1C = 0;
}


/**
  * @brief 30 degres interrupt
*/
#ifdef __GNUC__
  ISR(TIMER1_COMPA_vect)
#else
#pragma vector = TIMER1_COMPA_vect
__interrupt void thirty_degres_interrupt(void)
#endif
{
  char direction = mci_get_motor_direction();

  if (mci_motor_is_running())
  {

  switch(motor_step)
  {
    case (MS_100):
      if (direction==CCW)  {Set_Q1Q4();motor_step=MS_101;}
      else                 {Set_Q5Q2();motor_step=MS_110;}
      break;

    case (MS_110):
      if (direction==CCW)  {Set_Q5Q4();motor_step=MS_100;}
      else                 {Set_Q3Q2();motor_step=MS_010;}
      break;

    case (MS_010):
      if (direction==CCW)  {Set_Q5Q2();motor_step=MS_110;}
      else                 {Set_Q3Q6();motor_step=MS_011;}
      break;

    case (MS_011):
      if (direction==CCW)  {Set_Q3Q2();motor_step=MS_010;}
      else                 {Set_Q1Q6();motor_step=MS_001;}
      break;

    case (MS_001):
      if (direction==CCW)  {Set_Q3Q6();motor_step=MS_011;}
      else                 {Set_Q1Q4();motor_step=MS_101;}
      break;

    case (MS_101):
      if (direction==CCW)  {Set_Q1Q6();motor_step=MS_001;}
      else                 {Set_Q5Q4();motor_step=MS_100;}
      break;

    default :
      Set_none(); // all switches are switched OFF
      motor_step=MS_010;
      break;

  }
  }
}

/**
* @brief end of demagnetization delay interrupt
*/
#ifdef __GNUC__
  ISR(TIMER1_COMPB_vect)
#else
#pragma vector = TIMER1_COMPB_vect
__interrupt void demag_interrupt(void)
#endif
{

  switch(motor_step)
  {
    case (MS_100):
      Enable_IT_comparator0();
      break;

    case (MS_110):
      Enable_IT_comparator1();
      break;

    case (MS_010):
      Enable_IT_comparator2();
      break;

    case (MS_011):
      Enable_IT_comparator0();
      break;

    case (MS_001):
      Enable_IT_comparator1();
      break;

    case (MS_101):
      Enable_IT_comparator2();
      break;

    default :
      Enable_IT_comparator2_1_0();
      motor_step=MS_010;
      break;
  }
}

#define ADVANCE 70

#ifdef __GNUC__
  ISR(ANACOMP0_vect)
#else
#pragma vector = ANA_COMP0_vect
__interrupt void mc_comparator_0(void)
#endif 
{
  U16 top;
  U16 tmp1;
  U16 tmp2;
  U8 temp;
  TCCR1B = 0 ; // stop timer 1
  temp = TCNT1L;
  top = (TCNT1H<<8) + temp;
  TCNT1H = 0;
  TCNT1L = 0;
  top_average = ((U32)top_average*15 + top ) >> 4;
  tmp1 = (top_average >> 1);
  tmp2 = tmp1 + (top_average >> 2);
//  tmp2 = tmp1 + 40;
/*  if (tmp1 > (4*ADVANCE)) 
  {
    tmp1 = tmp1 - ADVANCE;
    tmp2 = tmp2 - ADVANCE;
  }*/
  OCR1AH = MSB(tmp1);
  OCR1AL = LSB(tmp1);
  OCR1BH = MSB(tmp2);
  OCR1BL = LSB(tmp2);
  TCCR1B = 1<<CS11 | 1<<CS10 ; // start timer 1
  Disable_IT_comparator2_1_0();

}

#ifdef __GNUC__
  ISR(ANACOMP1_vect)
#else
#pragma vector = ANA_COMP1_vect
__interrupt void mc_comparator_1(void)
#endif
{
  U16 top;
  U16 tmp1;
  U16 tmp2;
  U8 temp;
  TCCR1B = 0 ; // stop timer 1
  temp = TCNT1L;
  top = (TCNT1H<<8) + temp;
  TCNT1H = 0;
  TCNT1L = 0;
  top_average = ((U32)top_average*15 + top ) >> 4;
  tmp1 = (top_average >> 1);
  tmp2 = tmp1 + (top_average >> 2);
//  tmp2 = tmp1 + 40;
/*  if (tmp1 > (4*ADVANCE)) 
  {
    tmp1 = tmp1 - ADVANCE;
    tmp2 = tmp2 - ADVANCE;
  }*/
  OCR1AH = MSB(tmp1);
  OCR1AL = LSB(tmp1);
  OCR1BH = MSB(tmp2);
  OCR1BL = LSB(tmp2);
  TCCR1B = 1<<CS11 | 1<<CS10 ; // start timer 1
  Disable_IT_comparator2_1_0();
  mc_estimation_speed();
}

#ifdef __GNUC__
  ISR(ANACOMP2_vect)
#else
#pragma vector = ANA_COMP2_vect
__interrupt void mc_comparator_2(void)
#endif
{
  U16 top;
  U16 tmp1;
  U16 tmp2;
  U8 temp;
//Toggle_PE1();
  TCCR1B = 0 ; // stop timer 1
  temp = TCNT1L;
  top = (TCNT1H<<8) + temp;
  TCNT1H = 0;
  TCNT1L = 0;
  top_average = ((U32)top_average*15 + top ) >> 4;
  tmp1 = (top_average >> 1);
  tmp2 = tmp1 + (top_average >> 2);
//  tmp2 = tmp1 + 40;
/*  if (tmp1 > (4*ADVANCE)) 
  {
    tmp1 = tmp1 - ADVANCE;
    tmp2 = tmp2 - ADVANCE;
  }*/
  OCR1AH = MSB(tmp1);
  OCR1AL = LSB(tmp1);
  OCR1BH = MSB(tmp2);
  OCR1BL = LSB(tmp2);
  TCCR1B = 1<<CS11 | 1<<CS10 ; // start timer 1
  Disable_IT_comparator2_1_0();
}


void start_running_phase(void)
{
  U16 top;
  TCCR1B = 0 ; // stop timer 1
  top_average = TIMER1_AT_STARTUP_END;
  top = (top_average >> 1);
  TCNT1H = HIGH(top);
  TCNT1L = LOW(top);
  OCR1AH = 0;
  OCR1AL = 0;
  top = top + (top_average >> 2);
  OCR1BH = HIGH(top);
  OCR1BL = LOW(top);
  TCCR1B = (1<<CS11) | (1<<CS10) ; // start timer 1
  TIFR1 = (1<<OCF1B) | (1<<OCF1A) | (1<<TOV1);
  TIMSK1= (1<<OCIE1B) | (1<<OCIE1A); // Output compare A Match interrupt Enable
}

/******************************************************************************/
/******************************************************************************/
/*         TIMER 0 : Speed Measurement                                        */
/******************************************************************************/
/******************************************************************************/

/**
 * @brief Timer 0 Configuration
 * The timer 0 is used to generate an IT when an overflow occurs
 * @post Timer0 initialized.
*/
void mc_init_timer0(void)
{
  TCCR0A = 0;
  TCCR0B = (0<<CS02)|(1<<CS01)|(1<<CS00); // prescaler /64 (4us)
  TIMSK0 = (1<<TOIE0);
}

/**
  * @brief Timer0 Overflow => 4�S
*/

#ifdef __GNUC__
  ISR(TIMER0_OVF_vect)
#else
#pragma vector = TIMER0_OVF_vect
__interrupt void ovfl_timer0(void)
#endif
{
  timer0_ext++;
  g_tick = TRUE;
}

/**
* @brief estimation speed
* @pre configuration of timer 0 \n
*           and define or not AVERAGE_SPEED_MEASURENT in config_motor.h
* @post new value for real speed
*/
void mc_estimation_speed(void)
{
  U16 actual_time;
  U16 period_motor;

  // Two 8 bits variables are use to simulate a 16 bits timer
  actual_time = (timer0_ext<<8) + TCNT0;

  if (actual_time > stored_time)
  {
    period_motor = actual_time - stored_time;
  }
  else
  {
    period_motor = (U16)65535 - stored_time + actual_time;
  }

  stored_time = actual_time;

  mc_set_measured_period(period_motor>>1);

}

/******************************************************************************/
/******************************************************************************/
/*       ADC use for current and potentiometer measurement                    */
/******************************************************************************/
/******************************************************************************/

//! @brief Launch the sampling procedure to get current value
//! @pre amplifier and IT initialization
//! @post Set the End Of Conversion flag
#ifdef __GNUC__
  ISR(ADC_vect)
#else
#pragma vector = ADC_vect
__interrupt void ADC_end_of_conversion(void)
#endif
{
  Adc_select_channel(ADC_INPUT_GND); /* release the amplified channel */
  if(State == CONV_POT) mc_set_potentiometer_value(Adc_get_8_bits_result());
  if(State == CONV_CURRENT) mci_store_measured_current(Adc_get_10_bits_result());
  ADC_State = FREE;
}


//! @brief Launch the scheduler for the ADC
//! @post Get results for Potentiometer and current values.
void mc_ADC_Scheduler(void)
{
  switch(State)
  {
  case CONV_INIT :
    ADC_State = FREE;
    State = CONV_CURRENT;
    break;

  case CONV_CURRENT :              /* previous state was CONV_CURRENT */
    if(ADC_State == FREE)
    {
      ADC_State = BUSY;
      State= CONV_POT;                        /* new state is CONV_POT */
      Adc_left_adjust_result();
      Adc_start_conv_channel(ADC_INPUT_ISRC); /* get POT on ISRC input */
    }
    break;

  case CONV_POT :                           /* previous state was CONV_POT */
    if(ADC_State == FREE)
    {
      ADC_State = BUSY;
      State = CONV_CURRENT;                   /* new state is CONV_CURRENT */
      Adc_right_adjust_result();
      Adc_start_conv_channel(ADC_INPUT_AMP1); /* get current on amplifier 1 */
    }
    break;
  }
}

/******************************************************************************/
/******************************************************************************/
/*       Over Current Configuration                                           */
/******************************************************************************/
/******************************************************************************/


//! @brief the purpose of this function is to disable \n
//!   the overcurrent detection during startup (inrush current) \n
void mc_disable_during_inrush(void)
{
  inrush_delay = (U16) 500;
  inrush_mask_flag = TRUE;
  Disable_over_current();
}

//! @brief the purpose of this function is to manage the delay \n
//!   used when the overcurrent detection is disabled \n
void mc_inrush_task(void)
{ 
  if (inrush_mask_flag == TRUE)
  {
    if (inrush_delay-- == 0)
    {
      inrush_mask_flag = FALSE;
      Enable_over_current();
    }
  }
}

// Overcurrent detection
#ifdef __GNUC__
  ISR(PSC_FAULT_vect)
#else
#pragma vector = PSC_FAULT_vect
__interrupt void mc_overcurrent_detect(void)
#endif
{
  PIFR = (1<<PEV1); // clear the interrupt
  overcurrent = TRUE;
  mci_stop();
}
